import { createBrowserRouter, RouterProvider, Outlet } from 'react-router-dom'
import { Header, GlobalNav, Footer } from './components/Shell'
import HomePage from './pages/HomePage'
import CommunityHome from './pages/CommunityHome'
import PostList from './pages/PostList'
import PostCreate from './pages/PostCreate'
import PostDetail from './pages/PostDetail'
import SearchResults from './pages/SearchResults'
import Login from './pages/Login'
import SignupConsent from './pages/SignupConsent'
import SignupInfo from './pages/SignupInfo'
import SignupVerify from './pages/SignupVerify'
import WelfarePage from './pages/WelfarePage'
import HearingAidGuide from './pages/HearingAidGuide'

function Layout() {
  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ backgroundColor: '#F6F6F4', color: '#1A1918', fontFamily: "'Noto Sans KR', sans-serif" }}
    >
      <Header />
      <GlobalNav />
      <div style={{ flex: 1 }}>
        <Outlet />
      </div>
      <Footer />
    </div>
  )
}

function NotReady() {
  return (
    <main>
      <div style={{ maxWidth: 720, margin: '0 auto', padding: '80px 24px', textAlign: 'center' }}>
        <p style={{ fontSize: 15, color: '#908D88' }}>준비 중입니다.</p>
      </div>
    </main>
  )
}

const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      { path: '/', element: <HomePage /> },
      { path: '/community', element: <CommunityHome /> },
      { path: '/community/posts', element: <PostList /> },
      { path: '/community/posts/create', element: <PostCreate /> },
      { path: '/community/posts/:postId', element: <PostDetail /> },
      { path: '/search', element: <SearchResults /> },
      { path: '/login', element: <Login /> },
      { path: '/register', element: <SignupConsent /> },
      { path: '/register/info', element: <SignupInfo /> },
      { path: '/register/verify', element: <SignupVerify /> },
      { path: '/welfare', element: <WelfarePage /> },
      { path: '/validation/hearing-aid-health-insurance', element: <HearingAidGuide /> },
      { path: '/forgot-password', element: <NotReady /> },
      { path: '*', element: <NotReady /> },
    ],
  },
])

export default function App() {
  return <RouterProvider router={router} />
}

import { useState, useRef, useEffect, useMemo } from "react"
import { Link } from "react-router-dom"
import PRODUCTS_RAW from "@/data/hearingAidProducts.json"

/* ─── Types ─────────────────────────────────────────────────────────────────── */

type Q1 = "planning" | "assessment" | "waiting" | "registered" | "unknown"
type Q2 = "health" | "medical-aid" | "unknown"
type Q3 = "yes" | "no" | "unknown"
type Q4 = "first" | "previous" | "unknown"
type Q5 = "approved" | "waiting" | "not-applied" | "unknown"
type ResultCode = "R01" | "R02" | "R03" | "R04" | "R05" | "R06" | "R07" | "R08" | "R09" | "R10" | "R11" | "R12" | "R13" | "R14" | "R15" | "R16" | "R17" | "R18" | "R19" | "R20" | "R21"
type PageView = "summary" | "guided" | "reference" | "bilateral" | "product"
type GuidedStep = "Q1" | "Q2" | "Q3" | "Q4" | "Q5" | "done"
type StepStatus = "done" | "current" | "check-needed" | "future"

interface JStep {
  name: string
  institution: string
  desc: string
  status: StepStatus
  statusLabel: string
  detailLines: string[]
}

interface ResultInfo {
  title: string
  currentState: string
  institution: string
  nextAction: string
  contactQuestion: string | null
  centerNote: string | null
  questions: { text: string; purpose: string }[] | null
  hasHealthDetail: boolean
  onlineLink?: boolean
  secondary?: string | null
}

/* ─── Option data ───────────────────────────────────────────────────────────── */

const Q1_OPTS: { label: string; value: Q1 }[] = [
  { label: "아직 등록을 위한 검사·신청 전이에요", value: "planning" },
  { label: "병원에서 검사·진단을 받고 있어요", value: "assessment" },
  { label: "등록 신청 후 심사 결과를 기다려요", value: "waiting" },
  { label: "청각장애 등록을 마쳤어요", value: "registered" },
  { label: "어디까지 진행됐는지 잘 모르겠어요", value: "unknown" },
]
const Q2_OPTS: { label: string; value: Q2 }[] = [
  { label: "건강보험에 가입되어 있어요 (가족 포함)", value: "health" },
  { label: "의료급여 대상이에요", value: "medical-aid" },
  { label: "잘 모르겠어요", value: "unknown" },
]
const Q3_OPTS: { label: string; value: Q3 }[] = [
  { label: "예, 지원금 신청용 보청기 처방전을 받았어요", value: "yes" },
  { label: "아직 안 받았어요", value: "no" },
  { label: "잘 모르겠어요", value: "unknown" },
]
const Q4_OPTS: { label: string; value: Q4 }[] = [
  { label: "처음이에요", value: "first" },
  { label: "받은 적 있어요", value: "previous" },
  { label: "기억나지 않아요", value: "unknown" },
]
const Q5_OPTS: { label: string; value: Q5 }[] = [
  { label: "지원 가능하다는 안내를 받았어요", value: "approved" },
  { label: "신청하고 기다리고 있어요", value: "waiting" },
  { label: "아직 신청하지 않았어요", value: "not-applied" },
  { label: "잘 모르겠어요", value: "unknown" },
]

/* ─── Journey base steps ────────────────────────────────────────────────────── */

const BASE = [
  {
    name: "등록 확인",
    institution: "이비인후과 · 주민센터 · 국민연금공단",
    desc: "검사·진단 자료를 제출하고 심사를 거쳐 청각장애 등록 결과를 확인해요.",
  },
  {
    name: "병원 처방",
    institution: "이비인후과",
    desc: "장애등록용 진단과 별도로, 지원금 신청용 보청기 처방전을 받아요.",
  },
  {
    name: "구입·착용",
    institution: "보청기센터 · 판매업소",
    desc: "제품과 비용을 상담하고, 지원 절차를 확인한 뒤 구입해 착용해요.",
  },
  {
    name: "검수·청구",
    institution: "이비인후과 / 국민건강보험공단",
    desc: "구입 후 병원에서 착용 효과를 확인받고 지원금을 청구해요.",
  },
  {
    name: "이후 관리",
    institution: "보청기센터",
    desc: "구입 후에도 보청기를 조절·관리하며 다음 방문 일정을 정해요.",
  },
]

/* ─── Result info (all 15) ──────────────────────────────────────────────────── */

const RESULT_INFO: Record<ResultCode, ResultInfo> = {
  R01: {
    title: "등록 절차 알아보기",
    currentState: "청각장애 등록을 위한 검사·신청을 아직 시작하지 않았어요.",
    institution: "주소지 주민센터",
    nextAction:
      "방문해서 청각장애 등록 신청 방법과 진단받을 병원을 안내받으세요.",
    contactQuestion:
      "청각장애 등록을 처음 알아보고 있어요. 어떤 병원에서 검사받고, 검사 후에는 어디에 자료를 내면 되나요?",
    centerNote:
      "센터에서는 불편한 청취 상황과 제품을 상담할 수 있어요. 실제 구입은 등록·처방과 지원 절차를 확인한 뒤 결정하세요.",
    questions: [
      {
        text: "아직 등록을 위한 검사 전이에요. 구입을 결정하기 전에 제 청취 불편과 제품을 상담하고 비교해볼 수 있나요?",
        purpose: "현재 받을 수 있는 상담·제품 비교의 범위를 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
      {
        text: "지금 상담한 내용을 이어가려면 어떤 결과나 처방을 확인한 뒤 다시 방문하면 되나요?",
        purpose: "내 상황에 맞는 다음 센터 방문 시점과 준비할 내용을 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R02: {
    title: "등록 과정 중 검사·진단",
    currentState: "병원에서 청각장애 등록을 위한 검사·진단을 진행 중이에요.",
    institution: "지금 진료받는 이비인후과",
    nextAction:
      "다음 진료 때 남은 검사와 등록 신청용 자료를 받을 시점을 확인하세요.",
    contactQuestion:
      "청각장애 등록을 위한 검사를 진행 중이에요. 남은 검사와 진단 자료를 받는 날짜, 주민센터에 제출할 시점을 알려주세요.",
    centerNote:
      "검사 중에도 제품 상담은 받을 수 있어요. 상담 때 검사 중이라고 알리고, 실제 구입은 등록 결과와 지원금 신청용 처방을 확인한 뒤 준비하세요.",
    questions: [
      {
        text: "장애등록 검사·진단 중이에요. 구입을 결정하기 전에 제 청취 불편과 제품을 상담하고 비교해볼 수 있나요?",
        purpose: "현재 받을 수 있는 상담·제품 비교의 범위를 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
      {
        text: "지금 상담한 내용을 이어가려면 어떤 결과나 처방을 확인한 뒤 다시 방문하면 되나요?",
        purpose: "내 상황에 맞는 다음 센터 방문 시점과 준비할 내용을 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R03: {
    title: "등록 과정 중 심사·결과 대기",
    currentState: "등록 신청을 마치고 청각장애 심사 결과를 기다리고 있어요.",
    institution: "신청한 주민센터",
    nextAction:
      "방문하거나 안내받은 연락 방법으로 결과 통지 방법과 추가 자료 요청 여부를 확인하세요.",
    contactQuestion:
      "청각장애 등록 심사 결과를 기다리고 있어요. 결과는 어떤 방법으로 안내받고, 지금 추가로 제출할 자료가 있나요?",
    centerNote:
      "결과를 기다리는 동안 제품·비용 상담은 받을 수 있어요. 등록되면 지원금 신청용 처방을 확인하고 구입을 준비해요.",
    questions: [
      {
        text: "등록 심사 결과를 기다리고 있어요. 구입을 결정하기 전에 제 청취 불편과 제품을 상담하고 비교해볼 수 있나요?",
        purpose: "현재 받을 수 있는 상담·제품 비교의 범위를 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
      {
        text: "지금 상담한 내용을 이어가려면 어떤 결과나 처방을 확인한 뒤 다시 방문하면 되나요?",
        purpose: "내 상황에 맞는 다음 센터 방문 시점과 준비할 내용을 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R04: {
    title: "등록 진행 상태 확인 필요",
    currentState: "청각장애 등록이 어디까지 진행됐는지 확인이 필요해요.",
    institution: "주소지 주민센터",
    nextAction:
      "방문해서 등록 신청 기록과 결과가 있는지 확인하세요. 아래 문장을 보여줘도 돼요.",
    contactQuestion:
      "제가 청각장애 등록을 신청한 기록이 있나요? 심사 중인지, 등록이 완료됐는지와 다음에 제가 할 일을 확인해 주세요.",
    centerNote:
      "센터에서는 알고 있는 검사·진료 내용으로 상담받고, 현재 상태에 맞춰 도와줄 수 있는 범위를 물어보세요.",
    questions: [
      {
        text: "등록 진행 상태를 확인하고 있어요. 구입을 결정하기 전에 제 청취 불편과 제품을 상담하고 비교해볼 수 있나요?",
        purpose: "현재 받을 수 있는 상담·제품 비교의 범위를 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
      {
        text: "지금 상담한 내용을 이어가려면 어떤 결과나 처방을 확인한 뒤 다시 방문하면 되나요?",
        purpose: "내 상황에 맞는 다음 센터 방문 시점과 준비할 내용을 확인해요.",
      },
    ],
    hasHealthDetail: false,
    secondary:
      "신청 기록이 없고 병원 검사만 받았다면, 그 병원에서 장애등록용 검사였는지 확인하세요.",
  },
  R05: {
    title: "의료급여 사전 절차 확인 필요",
    currentState: "청각장애 등록을 마쳤고, 의료급여 대상이라고 답하셨어요.",
    institution: "주소지 주민센터",
    nextAction:
      "구입 전에 방문해서 의료급여 보청기 지원의 신청·승인 순서를 확인하세요.",
    contactQuestion:
      "청각장애 등록을 마친 의료급여 대상자예요. 보청기를 사기 전에 처방과 신청·승인을 어떤 순서로 진행해야 하나요?",
    centerNote:
      "센터에서는 의료급여 신청을 돕는 범위와 제품 상담을 받을 수 있어요. 건강보험의 금액·청구 절차를 그대로 적용하지 않아요.",
    questions: [
      {
        text: "의료급여 대상이에요. 처방과 주민센터 신청 절차를 진행 중이에요. 지금 제품을 상담하고, 신청 절차를 마친 뒤 구입을 준비할 수 있나요?",
        purpose: "현재 상담할 범위와 센터의 신청 지원 범위를 확인해요.",
      },
      {
        text: "지원 여부가 확인되면 제가 내는 금액과 포함된 관리 서비스를 나눠 설명해 주실 수 있나요?",
        purpose: "지원이 확인된 뒤 비교할 실제 부담액과 서비스를 확인해요.",
      },
      {
        text: "공식기관과 병원에서 확인한 뒤 어떤 내용을 가지고 다시 상담하면 되나요?",
        purpose: "미확인 내용을 해결한 뒤 이어갈 상담과 다음 방문을 준비해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R06: {
    title: "병원 처방 전",
    currentState:
      "청각장애 등록은 마쳤고, 지원금 신청용 보청기 처방전은 아직 받기 전이에요.",
    institution: "진료받을 이비인후과",
    nextAction:
      "방문 전 접수처에 지원금 신청용 보청기 처방 진료와 예약·준비사항을 문의하세요.",
    contactQuestion:
      "청각장애 등록을 마쳤어요. 보청기 건강보험 지원을 위한 처방 진료를 받으려면 어떻게 예약하고 무엇을 가져가면 되나요?",
    centerNote:
      "센터에서는 제품과 비용을 미리 상담할 수 있어요. 실제 구입 전에 처방전과 지원 절차를 확인하세요.",
    questions: [
      {
        text: "아직 지원금 신청용 보청기 처방전이 없어요. 지금 받을 수 있는 제품 상담과 병원 진료 후 다시 가져올 내용은 무엇인가요?",
        purpose: "현재 상담할 범위와 처방 확인 후 준비할 내용을 확인해요.",
      },
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R07: {
    title: "처방전 여부 확인 필요",
    currentState:
      "청각장애 등록은 마쳤고, 받은 서류가 지원금 신청용 보청기 처방전인지 확인이 필요해요.",
    institution: "진료받은 이비인후과",
    nextAction:
      "받은 서류가 있으면 병원 접수처에 보여주고, 지원금 신청용 처방전 발급 여부를 확인하세요.",
    contactQuestion:
      "제가 받은 서류가 지원금 신청용 보청기 처방전인가요? 아니라면 어떤 진료가 더 필요한가요?",
    centerNote:
      "센터에서는 제품과 비용을 미리 상담할 수 있어요. 실제 구입 전에 처방전과 지원 절차를 확인하세요.",
    questions: [
      {
        text: "받은 서류가 지원금 신청용 보청기 처방전인지 확인 중이에요. 확인 후 다시 상담할 때 무엇을 가져오면 되나요?",
        purpose: "현재 상담할 범위와 처방 확인 후 준비할 내용을 확인해요.",
      },
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R08: {
    title: "구입 전 제품·비용 상담",
    currentState:
      "청각장애 등록과 지원금 신청용 처방을 마쳤고, 지원금은 처음 신청한다고 답하셨어요.",
    institution: "상담할 보청기센터",
    nextAction:
      "제품 추천 이유와 실제 부담할 금액, 신청을 도와주는 범위를 상담하세요. 공단 등록 업소·제품인지도 함께 확인해요.",
    contactQuestion:
      "지원금은 처음 신청해요. 공단 등록 업소와 제품인지, 제가 내는 총금액과 포함된 관리 서비스, 구입 전에 직접 할 일을 알려주세요.",
    centerNote:
      "상담한 뒤 제품과 구입 시점을 결정하세요. 구입 이후에도 병원 확인과 센터 관리가 이어져요.",
    questions: [
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "제가 실제로 내는 총금액과 포함된 서비스는 무엇인가요? 청구를 맡길 수 있는지도 알려주세요.",
        purpose: "제품·관리 비용과 청구를 맡기는 범위를 확인해요.",
      },
      {
        text: "구입 후 병원 확인과 센터 관리는 언제 받나요? 관리에 포함되는 서비스와 별도 비용도 알려주세요.",
        purpose: "다음 방문 장소·일정과 관리 범위·비용을 확인해요.",
      },
    ],
    hasHealthDetail: true,
  },
  R09: {
    title: "구입 전, 이전 지원 이력 확인 필요",
    currentState:
      "지원금 신청용 처방전은 받았고, 이전 지원 날짜와 재지원 조건을 확인해야 해요.",
    institution: "국민건강보험공단",
    nextAction:
      "온라인 개인 상담이나 지사 방문으로 이전 보청기 구입·지원 기록과 이번 지원 가능 시점을 확인하세요.",
    contactQuestion:
      "이전에 보청기 건강보험 지원을 받은 기록과 구입 날짜를 확인해 주세요. 이번에 다시 지원받으려면 어떤 조건을 확인해야 하나요?",
    centerNote:
      "센터에서는 제품과 관리 조건을 상담하고, 사용 중인 보청기가 있다면 조절·수리도 함께 물어보세요. 실제 구입은 이력 확인 후 결정해요. 내구연한은 5년이지만, 기간이 지났다고 재지원이 확정되지는 않아요.",
    questions: [
      {
        text: "이전에 지원받은 적이 있어요. 구입할 제품을 상담하고, 사용 중인 보청기가 있다면 조절·수리와 새 제품 구입도 비교해볼 수 있나요?",
        purpose:
          "구입할 제품과, 사용 중인 보청기가 있다면 관리 대안도 비교해요.",
      },
      {
        text: "이번 지원 여부가 확인되면 실제 부담액과 관리 서비스를 비교해 주세요. 청구는 어디까지 도와주시나요?",
        purpose: "지원 확인 후의 비용과 센터 지원 범위를 확인해요.",
      },
      {
        text: "구입 후 병원 확인과 센터 관리는 언제 받나요? 관리에 포함되는 서비스와 별도 비용도 알려주세요.",
        purpose: "다음 방문 장소·일정과 관리 범위·비용을 확인해요.",
      },
    ],
    hasHealthDetail: true,
    onlineLink: true,
  },
  R10: {
    title: "구입 전, 이전 지원 이력 확인 필요",
    currentState:
      "지원금 신청용 처방전은 받았고, 이전 지원 이력은 확인이 필요해요.",
    institution: "국민건강보험공단",
    nextAction:
      "온라인 개인 상담이나 지사 방문으로 이전 보청기 지원 기록이 있는지부터 확인하세요.",
    contactQuestion:
      "이전에 보청기 건강보험 지원을 받은 기록이 있는지 확인해 주세요. 기록이 있다면 지원받은 날짜와 이번 신청 전에 확인할 조건을 알려주세요.",
    centerNote:
      "센터에서는 지금 상담할 수 있는 내용과 지원 이력 확인 후 구입 전에 점검할 내용을 물어보세요. 실제 구입은 기록 유무와 적용 조건을 확인한 뒤 결정해요.",
    questions: [
      {
        text: "이전 지원 여부를 확인 중이에요. 지금 상담할 수 있는 내용과 지원 이력 확인 후 구입 전에 점검할 내용을 알려주세요.",
        purpose: "현재 상담할 범위와 지원 기록 확인 후 점검할 내용을 구분해요.",
      },
      {
        text: "이번 지원 여부가 확인되면 실제 부담액과 관리 서비스를 비교해 주세요. 청구는 어디까지 도와주시나요?",
        purpose: "지원 확인 후의 비용과 센터 지원 범위를 확인해요.",
      },
      {
        text: "구입 후 병원 확인과 센터 관리는 언제 받나요? 관리에 포함되는 서비스와 별도 비용도 알려주세요.",
        purpose: "다음 방문 장소·일정과 관리 범위·비용을 확인해요.",
      },
    ],
    hasHealthDetail: true,
    onlineLink: true,
  },
  R11: {
    title: "보험 자격 확인 필요",
    currentState: "청각장애 등록은 마쳤고, 보험 자격은 확인이 필요해요.",
    institution: "국민건강보험공단",
    nextAction:
      "온라인 개인 상담이나 지사 방문으로 현재 보험 자격과 보청기 지원 절차를 확인하세요.",
    contactQuestion:
      "제가 현재 건강보험과 의료급여 중 어디에 해당하나요? 보청기 지원을 받으려면 구입 전에 무엇을 확인해야 하나요?",
    centerNote:
      "보험 자격을 확인하는 동안 제품 상담은 받을 수 있어요. 센터에는 자격이 미확인이라고 알리고, 지원액과 실제 구입 시점은 자격 확인 후 정하세요.",
    questions: [
      {
        text: "보험 자격은 아직 확인 중이에요. 지원금 신청용 보청기 처방전은 아직 없어요. 현재 제품을 상담하고, 제 제도가 확인되면 신청도 도움받을 수 있나요?",
        purpose:
          "지원 제도를 확정하기 전 상담할 내용과 센터의 신청 지원 범위를 확인해요.",
      },
      {
        text: "지원 여부가 확인되면 제가 내는 금액과 포함된 관리 서비스를 나눠 설명해 주실 수 있나요?",
        purpose: "지원이 확인된 뒤 비교할 실제 부담액과 서비스를 확인해요.",
      },
      {
        text: "공식기관과 병원에서 확인한 뒤 어떤 내용을 가지고 다시 상담하면 되나요?",
        purpose: "미확인 내용을 해결한 뒤 이어갈 상담과 다음 방문을 준비해요.",
      },
    ],
    hasHealthDetail: false,
    onlineLink: true,
    secondary:
      "처방전은 아직 받기 전이에요. 보험 자격을 확인한 뒤 해당 절차에 맞춰 이비인후과 진료를 준비하세요.",
  },
  R12: {
    title: "보험 자격 확인 필요",
    currentState: "청각장애 등록은 마쳤고, 보험 자격은 확인이 필요해요.",
    institution: "국민건강보험공단",
    nextAction:
      "온라인 개인 상담이나 지사 방문으로 현재 보험 자격과 보청기 지원 절차를 확인하세요.",
    contactQuestion:
      "제가 현재 건강보험과 의료급여 중 어디에 해당하나요? 보청기 지원을 받으려면 구입 전에 무엇을 확인해야 하나요?",
    centerNote:
      "보험 자격을 확인하는 동안 제품 상담은 받을 수 있어요. 센터에는 자격이 미확인이라고 알리고, 지원액과 실제 구입 시점은 자격 확인 후 정하세요.",
    questions: [
      {
        text: "보험 자격은 아직 확인 중이에요. 처방전 여부도 확인 중이에요. 현재 제품을 상담하고, 제 제도가 확인되면 신청도 도움받을 수 있나요?",
        purpose:
          "지원 제도를 확정하기 전 상담할 내용과 센터의 신청 지원 범위를 확인해요.",
      },
      {
        text: "지원 여부가 확인되면 제가 내는 금액과 포함된 관리 서비스를 나눠 설명해 주실 수 있나요?",
        purpose: "지원이 확인된 뒤 비교할 실제 부담액과 서비스를 확인해요.",
      },
      {
        text: "공식기관과 병원에서 확인한 뒤 어떤 내용을 가지고 다시 상담하면 되나요?",
        purpose: "미확인 내용을 해결한 뒤 이어갈 상담과 다음 방문을 준비해요.",
      },
    ],
    hasHealthDetail: false,
    onlineLink: true,
    secondary:
      '처방전 여부도 미확인이에요. 진료받은 병원에 "지원금 신청용 보청기 처방전을 발급받았나요?"라고 물어보세요.',
  },
  R13: {
    title: "보험 자격 확인 필요",
    currentState:
      "청각장애 등록과 지원금 신청용 처방은 마쳤고, 보험 자격은 확인이 필요해요.",
    institution: "국민건강보험공단",
    nextAction:
      "온라인 개인 상담이나 지사 방문으로 현재 보험 자격과 보청기 지원 절차를 확인하세요.",
    contactQuestion:
      "제가 현재 건강보험과 의료급여 중 어디에 해당하나요? 보청기 지원을 받으려면 구입 전에 무엇을 확인해야 하나요?",
    centerNote:
      "보험 자격을 확인하는 동안 제품 상담은 받을 수 있어요. 센터에는 자격이 미확인이라고 알리고, 지원액과 실제 구입 시점은 자격 확인 후 정하세요.",
    questions: [
      {
        text: "보험 자격은 아직 확인 중이에요. 지원금 신청용 보청기 처방전은 받았어요. 현재 제품을 상담하고, 제 제도가 확인되면 신청도 도움받을 수 있나요?",
        purpose:
          "지원 제도를 확정하기 전 상담할 내용과 센터의 신청 지원 범위를 확인해요.",
      },
      {
        text: "지원 여부가 확인되면 제가 내는 금액과 포함된 관리 서비스를 나눠 설명해 주실 수 있나요?",
        purpose: "지원이 확인된 뒤 비교할 실제 부담액과 서비스를 확인해요.",
      },
      {
        text: "공식기관과 병원에서 확인한 뒤 어떤 내용을 가지고 다시 상담하면 되나요?",
        purpose: "미확인 내용을 해결한 뒤 이어갈 상담과 다음 방문을 준비해요.",
      },
    ],
    hasHealthDetail: false,
    onlineLink: true,
  },
  R14: {
    title: "보험 자격 확인 필요",
    currentState:
      "청각장애 등록과 지원금 신청용 처방은 마쳤고, 보험 자격은 확인이 필요해요.",
    institution: "국민건강보험공단",
    nextAction:
      "온라인 개인 상담이나 지사 방문으로 현재 보험 자격과 보청기 지원 절차를 확인하세요.",
    contactQuestion:
      "제가 현재 건강보험과 의료급여 중 어디에 해당하나요? 보청기 지원을 받으려면 구입 전에 무엇을 확인해야 하나요? 이전 보청기 지원 기록도 어디에서 확인할 수 있나요?",
    centerNote:
      "보험 자격을 확인하는 동안 제품 상담은 받을 수 있어요. 센터에는 자격이 미확인이라고 알리고, 지원액과 실제 구입 시점은 자격 확인 후 정하세요.",
    questions: [
      {
        text: "보험 자격은 아직 확인 중이에요. 지원금 신청용 보청기 처방전은 받았어요. 현재 제품을 상담하고, 제 제도가 확인되면 신청도 도움받을 수 있나요?",
        purpose:
          "지원 제도를 확정하기 전 상담할 내용과 센터의 신청 지원 범위를 확인해요.",
      },
      {
        text: "지원 여부가 확인되면 제가 내는 금액과 포함된 관리 서비스를 나눠 설명해 주실 수 있나요?",
        purpose: "지원이 확인된 뒤 비교할 실제 부담액과 서비스를 확인해요.",
      },
      {
        text: "보험 자격과 이전 지원 기록을 확인한 뒤 어떤 내용을 가지고 다시 상담하면 되나요?",
        purpose: "미확인 내용을 해결한 뒤 이어갈 상담과 다음 방문을 준비해요.",
      },
    ],
    hasHealthDetail: false,
    onlineLink: true,
  },
  R15: {
    title: "보험 자격 확인 필요",
    currentState:
      "청각장애 등록과 지원금 신청용 처방은 마쳤고, 보험 자격은 확인이 필요해요.",
    institution: "국민건강보험공단",
    nextAction:
      "온라인 개인 상담이나 지사 방문으로 현재 보험 자격과 보청기 지원 절차를 확인하세요.",
    contactQuestion:
      "제가 현재 건강보험과 의료급여 중 어디에 해당하나요? 보청기 지원을 받으려면 구입 전에 무엇을 확인해야 하나요? 이전 보청기 지원 기록도 어디에서 확인할 수 있나요?",
    centerNote:
      "보험 자격을 확인하는 동안 제품 상담은 받을 수 있어요. 센터에는 자격이 미확인이라고 알리고, 지원액과 실제 구입 시점은 자격 확인 후 정하세요.",
    questions: [
      {
        text: "보험 자격은 아직 확인 중이에요. 지원금 신청용 보청기 처방전은 받았어요. 현재 제품을 상담하고, 제 제도가 확인되면 신청도 도움받을 수 있나요?",
        purpose:
          "지원 제도를 확정하기 전 상담할 내용과 센터의 신청 지원 범위를 확인해요.",
      },
      {
        text: "지원 여부가 확인되면 제가 내는 금액과 포함된 관리 서비스를 나눠 설명해 주실 수 있나요?",
        purpose: "지원이 확인된 뒤 비교할 실제 부담액과 서비스를 확인해요.",
      },
      {
        text: "보험 자격과 이전 지원 기록을 확인한 뒤 어떤 내용을 가지고 다시 상담하면 되나요?",
        purpose: "미확인 내용을 해결한 뒤 이어갈 상담과 다음 방문을 준비해요.",
      },
    ],
    hasHealthDetail: false,
    onlineLink: true,
  },
  R16: {
    title: "병원 처방 상담 단계",
    currentState:
      "청각장애 등록을 마쳤고, 의료급여 대상이에요. 지원금 신청용 보청기 처방전은 아직 받기 전이에요.",
    institution: "진료받을 이비인후과",
    nextAction:
      "의료급여 보청기 지원을 위한 처방 진료를 예약하고, 필요한 검사와 준비사항을 문의하세요.",
    contactQuestion:
      "의료급여 대상 청각장애인이에요. 보청기 지원을 위한 처방 진료를 받으려면 어떻게 예약하고 무엇을 준비해야 하나요?",
    centerNote:
      "처방 전에도 제품과 비용을 상담할 수 있어요. 실제 구입은 처방과 주민센터 신청·결정 통보 이후에 진행해요.",
    questions: [
      {
        text: "아직 지원금 신청용 보청기 처방전이 없어요. 처방 진료 후 다시 방문할 때 무엇을 가져오면 되나요?",
        purpose: "현재 상담할 범위와 처방 확인 후 준비할 내용을 확인해요.",
      },
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R17: {
    title: "받은 서류 확인 필요",
    currentState:
      "청각장애 등록을 마쳤고, 의료급여 대상이에요. 받은 서류가 지원금 신청용 처방전인지 확인이 필요해요.",
    institution: "진료받은 이비인후과",
    nextAction:
      "받은 서류를 병원 접수처에 보여주고, 의료급여 보청기 지원용 처방전인지 확인하세요.",
    contactQuestion:
      "제가 받은 서류가 의료급여 보청기 지원용 처방전인가요? 아니라면 어떤 진료가 더 필요한가요?",
    centerNote:
      "처방 확인 전에도 제품 상담은 받을 수 있어요. 실제 구입은 처방과 주민센터 신청·결정 통보 이후에 진행해요.",
    questions: [
      {
        text: "받은 서류가 의료급여 보청기 지원용 처방전인지 확인 중이에요. 확인 후 다시 상담할 때 무엇을 가져오면 되나요?",
        purpose: "현재 상담할 범위와 처방 확인 후 준비할 내용을 확인해요.",
      },
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R18: {
    title: "센터 상담·구입 준비 단계",
    currentState:
      "처방을 마쳤고, 주민센터에서 보청기 지원 가능 안내를 받으셨어요. 이제 센터에서 제품과 비용을 상담하세요.",
    institution: "상담할 보청기센터",
    nextAction:
      "안내받은 지원 조건을 바탕으로 센터에서 제품·비용과 구입 전 확인 사항을 상담하세요.",
    contactQuestion:
      "의료급여 보청기 지원 결정 통보를 받았어요. 통보서를 보여드릴게요. 제 조건에 맞는 제품과 제가 실제로 내는 금액, 구입 절차를 설명해 주세요.",
    centerNote:
      "상담한 뒤 제품과 구입 시점을 결정하세요. 구입 후에도 병원 검수 확인과 청구 절차가 이어져요.",
    questions: [
      {
        text: "의료급여 보청기 지원 결정을 받았어요. 제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "제가 실제로 내는 금액과 포함된 서비스는 무엇인가요? 구입 후 청구 절차도 안내해 주세요.",
        purpose: "실제 부담액, 포함된 서비스, 청구 방법을 확인해요.",
      },
      {
        text: "구입 후 병원 검수 확인과 센터 관리는 언제 받나요? 관리에 포함되는 서비스와 별도 비용도 알려주세요.",
        purpose: "다음 방문 장소·일정과 관리 범위·비용을 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R19: {
    title: "주민센터 신청 결과 대기 중",
    currentState:
      "처방을 마치고 주민센터에 보청기 지원을 신청한 상태예요. 결과 안내를 기다리고 있어요.",
    institution: "신청한 주민센터·시군구 담당자",
    nextAction:
      "신청을 접수한 담당자에게 처리 상태와 결과 통지 방법을 확인하세요.",
    contactQuestion:
      "보청기 의료급여 지원을 신청하고 기다리고 있어요. 처리 상태와 결과는 어떤 방법으로 안내받나요? 지금 추가로 제출할 자료가 있나요?",
    centerNote:
      "대기 중에도 제품 상담은 받을 수 있어요. 실제 구입은 주민센터 결정 통보를 받은 뒤 진행해요.",
    questions: [
      {
        text: "주민센터에 신청하고 기다리고 있어요. 지금 제품을 상담하고, 결정 통보 후 구입 절차도 미리 안내받을 수 있나요?",
        purpose: "현재 상담할 범위와 결정 이후 구입 절차를 미리 확인해요.",
      },
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R20: {
    title: "주민센터 신청 단계",
    currentState:
      "처방을 마쳤고, 주민센터에 보청기 지원 신청을 아직 하지 않았어요.",
    institution: "주소지 주민센터",
    nextAction:
      "처방전을 가져가 주민센터에 의료급여 보청기 지원 신청 방법을 문의하세요.",
    contactQuestion:
      "청각장애 등록과 보청기 처방전을 마쳤어요. 의료급여 보청기 지원을 신청하려면 어떤 서류를 가져와야 하고, 신청 후 어떤 순서로 진행되나요?",
    centerNote:
      "신청 전에도 제품 상담은 받을 수 있어요. 실제 구입은 주민센터 결정 통보를 받은 뒤 진행해요.",
    questions: [
      {
        text: "아직 주민센터에 신청하지 않았어요. 지금 제품을 상담하고, 신청 후 구입 절차도 미리 안내받을 수 있나요?",
        purpose: "현재 상담할 범위와 신청 이후 구입 절차를 미리 확인해요.",
      },
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
  R21: {
    title: "주민센터 신청 상태 확인 필요",
    currentState:
      "처방을 마쳤고, 주민센터에 보청기 지원을 신청했는지와 처리 상태를 확인해야 해요.",
    institution: "주소지 주민센터·시군구 담당자",
    nextAction:
      "주민센터 담당자에게 이번 보청기 지원의 신청 기록과 처리 상태를 확인하세요.",
    contactQuestion:
      "청각장애 등록과 보청기 처방을 마쳤어요. 보청기 의료급여 지원을 신청한 기록이 있는지, 있다면 처리 상태를 확인해 주세요.",
    centerNote:
      "신청 상태를 확인하는 동안 제품 상담은 받을 수 있어요. 실제 구입은 주민센터 결정 통보를 받은 뒤 진행해요.",
    questions: [
      {
        text: "신청 상태를 확인 중이에요. 지금 제품을 상담하고, 결정 통보 후 구입 절차도 미리 안내받을 수 있나요?",
        purpose: "현재 상담할 범위와 결정 이후 구입 절차를 미리 확인해요.",
      },
      {
        text: "제 청력과 생활환경에 왜 이 제품을 추천하나요? 비교할 수 있는 다른 제품도 알려주세요.",
        purpose: "추천 이유와 비교 대안을 확인해요.",
      },
      {
        text: "센터에서 신청을 도와주는 범위와 제가 직접 방문하거나 서명할 일은 무엇인가요?",
        purpose: "센터의 지원 범위와 내가 직접 해야 할 일을 나눠 확인해요.",
      },
    ],
    hasHealthDetail: false,
  },
}

/* ─── Product data ──────────────────────────────────────────────────────────── */

interface Product {
  id: string
  model: string
  company: string
  price: number
  group: string
}

const PRODUCTS_META = PRODUCTS_RAW as {
  sourceUrl: string
  notice: string
  effectiveAt: string
  checkedAt: string
  products: Product[]
}

const NHIS_ONLINE_URL =
  "https://www.nhis.or.kr/nhis/minwon/retrieveCvaplCstInfoColctAgreView.do"

function normalizeSearch(s: string): string {
  return s
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[\s\-]/g, "")
}

const BRAND_ALIASES: Record<string, string[]> = {
  starkey: ["스타키"],
  phonak: ["포낙"],
}

function searchProducts(query: string): Product[] {
  const q = normalizeSearch(query)
  if (!q) return []
  const aliasQ = Object.entries(BRAND_ALIASES).reduce((acc, [eng, kor]) => {
    kor.forEach((k) => {
      if (normalizeSearch(k) === q || normalizeSearch(k).includes(q))
        acc = normalizeSearch(eng)
    })
    if (normalizeSearch(eng) === q || normalizeSearch(eng).includes(q)) {
      kor.forEach((k) => {
        acc = normalizeSearch(k)
      })
    }
    return acc
  }, q)

  const exact: Product[] = []
  const partial: Product[] = []
  PRODUCTS_META.products.forEach((p) => {
    const nm = normalizeSearch(p.model)
    const id = normalizeSearch(p.id)
    const co = normalizeSearch(p.company)
    if (nm === q || id === q || nm === aliasQ || id === aliasQ) {
      exact.push(p)
    } else if (
      nm.includes(q) ||
      id.includes(q) ||
      co.includes(q) ||
      nm.includes(aliasQ) ||
      id.includes(aliasQ) ||
      co.includes(aliasQ)
    ) {
      partial.push(p)
    }
  })
  return [...exact, ...partial]
}

function formatPrice(n: number): string {
  return n.toLocaleString("ko-KR") + "원"
}

/* ─── CopyButton (bilateral variant) ────────────────────────────────────────── */

function BilateralCopyButton({
  copyText,
  successMsg,
}: {
  copyText: string
  successMsg: string
}) {
  const [status, setStatus] = useState<"idle" | "success" | "fail">("idle")
  const [showFallback, setShowFallback] = useState(false)
  const fallbackRef = useRef<HTMLTextAreaElement>(null)

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(copyText)
      setStatus("success")
      setShowFallback(false)
    } catch {
      setStatus("fail")
      setShowFallback(true)
      setTimeout(() => {
        fallbackRef.current?.focus()
        fallbackRef.current?.select()
      }, 50)
    }
  }

  return (
    <div style={{ marginTop: 12 }}>
      <button
        type="button"
        onClick={handleCopy}
        style={{
          display: "inline-flex",
          alignItems: "center",
          minHeight: 44,
          padding: "10px 18px",
          border: "1.5px solid #1A1918",
          borderRadius: 2,
          backgroundColor: "transparent",
          color: "#1A1918",
          fontSize: 14,
          fontWeight: 600,
          cursor: "pointer",
          fontFamily: "inherit",
        }}
      >
        질문 복사하기
      </button>
      <div
        role="status"
        aria-live="polite"
        style={{ marginTop: 8, fontSize: 13 }}
      >
        {status === "success" && (
          <span style={{ color: "#166534" }}>{successMsg}</span>
        )}
        {status === "fail" && (
          <span style={{ color: "#92400E" }}>
            자동 복사가 되지 않았어요. 아래 내용을 선택해 복사해 주세요.
          </span>
        )}
      </div>
      {showFallback && (
        <textarea
          ref={fallbackRef}
          readOnly
          value={copyText}
          aria-label="복사할 질문"
          onFocus={(e) => e.target.select()}
          rows={10}
          style={{
            display: "block",
            width: "100%",
            marginTop: 8,
            fontSize: 12,
            lineHeight: 1.7,
            padding: "10px 12px",
            fontFamily: "inherit",
            border: "1px solid #D0CEC9",
            borderRadius: 2,
            backgroundColor: "#FAFAF8",
            resize: "vertical",
            boxSizing: "border-box",
          }}
        />
      )}
    </div>
  )
}

/* ─── Step institution/detail helpers (per-insurance) ──────────────────────── */

function stepInstitution(idx: number, q2: Q2 | null): string {
  if (idx === 3) {
    if (q2 === "medical-aid")
      return "이비인후과 · 청구 절차는 주민센터에서 확인"
    if (q2 === "health")
      return "이비인후과 · 위임 청구: 판매업소 / 직접 청구: 국민건강보험공단"
    return "이비인후과 · 건강보험 청구: 판매업소 위임 또는 국민건강보험공단"
  }
  return BASE[idx].institution
}

function stepDetails(idx: number, q1: Q1 | null, q2: Q2 | null): string[] {
  if (idx === 0) {
    const base = [
      "내부 흐름: 검사·진단(이비인후과) → 등록 신청·자료 제출(주소지 주민센터) → 장애정도 심사(국민연금공단) → 등록 결과 확인(주민센터)",
      "단순 난청 진단은 청각장애 등록 완료가 아니에요.",
    ]
    if (q1 === "assessment") base.push("현재 위치: 검사·진단 중")
    if (q1 === "waiting") base.push("현재 위치: 장애정도 심사 대기")
    return base
  }
  if (idx === 1) {
    return [
      "장애등록용 진단서·검사 자료와 지원금 신청용 처방전(보조기기 처방전)은 별도 서류예요.",
    ]
  }
  if (idx === 2) {
    if (q2 === "medical-aid") {
      return [
        "의료급여는 구입 전에 주민센터에서 지원 신청을 하고 결정 통보를 받는 절차가 있어요.",
        "결정 통보를 받은 뒤 센터에서 제품을 구입해요.",
        "공단 등록 업소·제품인지 확인해요.",
      ]
    }
    return [
      "공단 등록 업소·제품인지 확인해요.",
      "제품 추천 이유, 실제 부담 금액, 신청 지원 범위를 상담하세요.",
      "상담 후 제품과 구입 시점을 결정해요.",
    ]
  }
  if (idx === 3) {
    if (q2 === "medical-aid")
      return [
        "이비인후과에서 착용 효과 확인(검수확인)을 받아요.",
        "의료급여 청구 절차는 구입 전에 주민센터에서 확인하세요.",
      ]
    if (q2 === "health")
      return [
        "구입 후 1개월이 지난 뒤 이비인후과에서 착용 효과 확인(검수확인)을 받아요.",
        "위임 청구: 판매업소에 청구를 맡겨요. 위임장·신분증 사본 등 필요 자료를 안내받으세요.",
        "직접 청구: 지급청구서와 자료를 국민건강보험공단에 제출해요.",
      ]
    return [
      "이비인후과에서 착용 효과 확인(검수확인)을 받아요.",
      "건강보험: 판매업소 위임 또는 국민건강보험공단에 직접 청구해요.",
      "보험 자격을 먼저 확인한 뒤 해당 절차를 따르세요.",
    ]
  }
  if (idx === 4) {
    const lines = ["구입 후 1년부터 5년까지 보청기센터에서 조절·관리를 받아요."]
    if (q2 === "health") {
      lines.push("연 1회 이상 실제 관리를 받은 뒤 관리비를 따로 청구해요.")
    }
    return lines
  }
  return []
}

/* ─── Computation helpers ───────────────────────────────────────────────────── */

function getCurrentStep(
  q1: Q1 | null,
  q2: Q2 | null,
  q3: Q3 | null,
  q4: Q4 | null,
  q5?: Q5 | null,
): GuidedStep {
  if (!q1) return "Q1"
  if (q1 !== "registered") return "done"
  if (!q2) return "Q2"
  if (q2 === "medical-aid") {
    if (!q3) return "Q3"
    if (q3 !== "yes") return "done"
    if (!q5) return "Q5"
    return "done"
  }
  if (!q3) return "Q3"
  if (q3 !== "yes") return "done"
  if (!q4) return "Q4"
  return "done"
}

function getLastAnsweredQ(
  q1: Q1 | null,
  q2: Q2 | null,
  q3: Q3 | null,
  q4: Q4 | null,
  q5?: Q5 | null,
): "Q1" | "Q2" | "Q3" | "Q4" | "Q5" | null {
  if (!q1) return null
  if (q1 !== "registered") return "Q1"
  if (!q2) return null
  if (q2 === "medical-aid") {
    if (!q3) return "Q2"
    if (q3 !== "yes") return "Q3"
    if (!q5) return "Q3"
    return "Q5"
  }
  if (!q3) return null
  if (q3 !== "yes") return "Q3"
  if (!q4) return null
  return "Q4"
}

function computeResult(
  q1: Q1 | null,
  q2: Q2 | null,
  q3: Q3 | null,
  q4: Q4 | null,
  q5?: Q5 | null,
): ResultCode | null {
  if (!q1) return null
  if (q1 === "planning") return "R01"
  if (q1 === "assessment") return "R02"
  if (q1 === "waiting") return "R03"
  if (q1 === "unknown") return "R04"
  if (!q2) return null
  if (q2 === "medical-aid") {
    if (!q3) return null
    if (q3 === "no") return "R16"
    if (q3 === "unknown") return "R17"
    if (!q5) return null
    if (q5 === "approved") return "R18"
    if (q5 === "waiting") return "R19"
    if (q5 === "not-applied") return "R20"
    return "R21"
  }
  if (!q3) return null
  if (q3 === "no") return q2 === "health" ? "R06" : "R11"
  if (q3 === "unknown") return q2 === "health" ? "R07" : "R12"
  if (!q4) return null
  if (q4 === "first") return q2 === "health" ? "R08" : "R13"
  if (q4 === "previous") return q2 === "health" ? "R09" : "R14"
  return q2 === "health" ? "R10" : "R15"
}

function makeStep(
  idx: number,
  status: StepStatus,
  statusLabel: string,
  q1: Q1 | null,
  q2: Q2 | null,
): JStep {
  return {
    ...BASE[idx],
    institution: stepInstitution(idx, q2),
    status,
    statusLabel,
    detailLines: stepDetails(idx, q1, q2),
  }
}

function computeJourney(
  q1: Q1 | null,
  q2: Q2 | null,
  q3: Q3 | null,
  q4: Q4 | null,
  q5?: Q5 | null,
): JStep[] {
  const F = (i: number) => makeStep(i, "future", "이후 과정", q1, q2)

  if (!q1 || q1 === "unknown") {
    const s0status: StepStatus = q1 === "unknown" ? "check-needed" : "future"
    const s0label = q1 === "unknown" ? "진행 상태 확인 필요" : "이후 과정"
    return [makeStep(0, s0status, s0label, q1, q2), F(1), F(2), F(3), F(4)]
  }
  if (q1 === "planning")
    return [
      makeStep(0, "current", "검사 전·신청 전", q1, q2),
      F(1),
      F(2),
      F(3),
      F(4),
    ]
  if (q1 === "assessment")
    return [
      makeStep(0, "current", "검사·진단 중", q1, q2),
      F(1),
      F(2),
      F(3),
      F(4),
    ]
  if (q1 === "waiting")
    return [
      makeStep(0, "current", "심사 결과 대기", q1, q2),
      F(1),
      F(2),
      F(3),
      F(4),
    ]

  const s0 = makeStep(0, "done", "등록 완료", q1, q2)

  if (!q2) return [s0, F(1), F(2), F(3), F(4)]

  if (q2 === "medical-aid") {
    if (!q3) {
      return [s0, F(1), makeStep(2, "check-needed", "구입 전 신청·결정 필요", q1, q2), F(3), F(4)]
    }
    if (q3 === "no") {
      return [s0, makeStep(1, "current", "처방 받기 전", q1, q2), makeStep(2, "check-needed", "구입 전 신청·결정 필요", q1, q2), F(3), F(4)]
    }
    if (q3 === "unknown") {
      return [s0, makeStep(1, "check-needed", "처방 확인 필요", q1, q2), makeStep(2, "check-needed", "구입 전 신청·결정 필요", q1, q2), F(3), F(4)]
    }
    // q3 === "yes"
    const s1done = makeStep(1, "done", "처방 완료", q1, q2)
    if (!q5) {
      return [s0, s1done, makeStep(2, "check-needed", "신청 상태 확인 필요", q1, q2), F(3), F(4)]
    }
    if (q5 === "approved") {
      return [s0, s1done, makeStep(2, "current", "센터 상담·구입 준비", q1, q2), F(3), F(4)]
    }
    if (q5 === "waiting") {
      return [s0, s1done, makeStep(2, "current", "신청 결과 대기", q1, q2), F(3), F(4)]
    }
    if (q5 === "not-applied") {
      return [s0, s1done, makeStep(2, "current", "주민센터 신청 전", q1, q2), F(3), F(4)]
    }
    return [s0, s1done, makeStep(2, "check-needed", "신청 상태 확인 필요", q1, q2), F(3), F(4)]
  }

  if (!q3) return [s0, F(1), F(2), F(3), F(4)]

  if (q3 === "no") {
    const label = q2 === "health" ? "처방전 받기 전" : "보험·처방 확인 필요"
    const status: StepStatus = q2 === "health" ? "current" : "check-needed"
    return [s0, makeStep(1, status, label, q1, q2), F(2), F(3), F(4)]
  }
  if (q3 === "unknown") {
    const label =
      q2 === "health" ? "처방전 여부 확인 필요" : "보험·처방 확인 필요"
    return [s0, makeStep(1, "check-needed", label, q1, q2), F(2), F(3), F(4)]
  }

  const s1 = makeStep(1, "done", "처방전 받음", q1, q2)

  if (!q4) return [s0, s1, F(2), F(3), F(4)]

  if (q2 === "health") {
    if (q4 === "first")
      return [
        s0,
        s1,
        makeStep(2, "current", "제품·비용 상담", q1, q2),
        F(3),
        F(4),
      ]
    const label = q4 === "previous" ? "이전 이력 확인 필요" : "이력 확인 필요"
    return [s0, s1, makeStep(2, "check-needed", label, q1, q2), F(3), F(4)]
  }
  const label =
    q4 === "previous" ? "보험·이력 확인 필요" : "보험 자격 확인 필요"
  return [s0, s1, makeStep(2, "check-needed", label, q1, q2), F(3), F(4)]
}

function getJourneyNote(code: ResultCode): string | null {
  if (["R06", "R07", "R08", "R09", "R10"].includes(code)) return null
  if (code === "R05")
    return "아래는 기관별 큰 흐름이에요. 의료급여의 신청·승인과 청구 순서는 구입 전 주민센터에서 확인하세요."
  return "아래는 기본 흐름이에요. 보험 자격에 따라 구입 전 승인과 청구 절차가 달라질 수 있어요."
}

function computeTopBarSteps(
  q1: Q1 | null,
  q2: Q2 | null,
  q3: Q3 | null,
  q4: Q4 | null,
  step: GuidedStep,
  q5?: Q5 | null,
): JStep[] {
  const F = (i: number) => makeStep(i, "future", "", q1, q2)

  if (step === "Q1")
    return [
      makeStep(0, "current", "지금 확인 중", q1, q2),
      F(1),
      F(2),
      F(3),
      F(4),
    ]

  const s0 = makeStep(0, "done", "등록 완료", q1, q2)
  if (step === "Q2") return [s0, F(1), F(2), F(3), F(4)]
  if (step === "Q3")
    return [
      s0,
      makeStep(1, "current", "지금 확인 중", q1, q2),
      F(2),
      F(3),
      F(4),
    ]
  if (step === "Q4")
    return [s0, makeStep(1, "done", "처방전 받음", q1, q2), F(2), F(3), F(4)]
  if (step === "Q5")
    return [s0, makeStep(1, "done", "처방 완료", q1, q2), makeStep(2, "check-needed", "신청 상태 확인 중", q1, q2), F(3), F(4)]

  return computeJourney(q1, q2, q3, q4, q5)
}

function computeFacts(
  q1: Q1 | null,
  q2: Q2 | null,
  q3: Q3 | null,
  q4: Q4 | null,
  code: ResultCode,
  q5?: Q5 | null,
): { label: string; value: string }[] {
  if (code === "R02")
    return [
      { label: "진행 중", value: "병원 검사·진단" },
      { label: "확인할 일", value: "남은 검사와 주민센터에 제출할 시점" },
    ]
  if (code === "R08")
    return [
      {
        label: "마친 일",
        value: "청각장애 등록 · 지원금 신청용 보청기 처방전 받기",
      },
      { label: "답변한 내용", value: "보청기 지원금은 처음 신청" },
    ]

  const facts: { label: string; value: string }[] = []
  if (!q1) return facts

  if (q1 !== "registered") {
    const map: Record<Q1, string> = {
      planning: "등록 검사·신청 전",
      assessment: "병원 검사·진단 중",
      waiting: "등록 신청 후 심사 대기",
      registered: "",
      unknown: "등록 진행 상태 모름",
    }
    facts.push({ label: "답변한 내용", value: map[q1] })
    return facts
  }

  facts.push({ label: "마친 일", value: "청각장애 등록" })
  if (q2) {
    const map: Record<Q2, string> = {
      health: "건강보험",
      "medical-aid": "의료급여",
      unknown: "미확인",
    }
    facts.push({ label: "보험 자격", value: map[q2] })
  }
  if (q3) {
    const map: Record<Q3, string> = {
      yes: "지원금 신청용 처방전 받음",
      no: "미수령",
      unknown: "여부 미확인",
    }
    facts.push({ label: "처방전", value: map[q3] })
  }
  if (q4) {
    const map: Record<Q4, string> = {
      first: "처음 신청",
      previous: "이전 이력 있음",
      unknown: "이력 미확인",
    }
    facts.push({ label: "지원 이력", value: map[q4] })
  }
  if (q5) {
    const map: Record<Q5, string> = {
      approved: "지원 가능 안내 받음",
      waiting: "신청 결과 대기 중",
      "not-applied": "신청 전",
      unknown: "상태 미확인",
    }
    facts.push({ label: "의료급여 신청", value: map[q5] })
  }
  return facts
}

function buildCopyText(
  info: ResultInfo,
  facts: { label: string; value: string }[],
): string {
  if (!info.questions || !info.contactQuestion) return ""
  return [
    "IYUM · 센터 방문 전 상담 질문",
    `내 상황: ${info.title}`,
    ...facts.map((f) => `${f.label}: ${f.value}`),
    "",
    `먼저 확인할 곳: ${info.institution}`,
    `문의할 내용: ${info.contactQuestion}`,
    "",
    ...info.questions.flatMap((q, i) => [
      `${i + 1}. ${q.text}`,
      `   확인할 것: ${q.purpose}`,
    ]),
  ].join("\n")
}

/* ─── Step color helpers ─────────────────────────────────────────────────────── */

function stepColors(s: StepStatus) {
  switch (s) {
    case "done":
      return {
        bg: "#F0EEE9",
        text: "#4A4845",
        badge: "#908D88",
        border: "#D0CEC9",
      }
    case "current":
      return {
        bg: "#FEF3C7",
        text: "#78350F",
        badge: "#92400E",
        border: "#FCD34D",
      }
    case "check-needed":
      return {
        bg: "#FFFBEB",
        text: "#78350F",
        badge: "#A16207",
        border: "#FDE68A",
      }
    case "future":
      return {
        bg: "#FAFAF8",
        text: "#4A4845",
        badge: "#6B6864",
        border: "#D0CEC9",
      }
  }
}

/* Compact bar uses neutral for check-needed so it isn't mistaken for a confirmed current step */
function compactStepColors(s: StepStatus) {
  if (s === "check-needed")
    return {
      bg: "#F5F3F0",
      text: "#4A4845",
      badge: "#6B6864",
      border: "#D0CEC9",
    }
  return stepColors(s)
}

/* ─── CompactJourneyBar ─────────────────────────────────────────────────────── */

function CompactJourneyBar({ steps }: { steps: JStep[] }) {
  return (
    <div
      role="list"
      aria-label="전체 절차와 현재 위치"
      style={{
        display: "flex",
        borderTop: "1px solid #D0CEC9",
        borderBottom: "1px solid #D0CEC9",
        borderLeft: "1px solid #D0CEC9",
        borderRight: "1px solid #D0CEC9",
        borderRadius: 2,
        overflow: "hidden",
        marginBottom: 20,
      }}
    >
      {steps.map((step, i) => {
        const c = compactStepColors(step.status)
        return (
          <div
            key={i}
            role="listitem"
            style={{
              flex: 1,
              padding: "7px 3px",
              backgroundColor: c.bg,
              borderLeft: i > 0 ? "1px solid #D0CEC9" : "none",
              textAlign: "center",
              minWidth: 0,
            }}
          >
            <div
              style={{
                fontSize: 11,
                fontFamily: "'DM Mono', monospace",
                color: c.badge,
                marginBottom: 2,
              }}
            >
              {step.status === "done" ? "✓" : `0${i + 1}`}
            </div>
            <div
              style={{
                fontSize: 11,
                fontWeight: step.status === "current" ? 700 : 500,
                color: c.text,
                lineHeight: 1.2,
                wordBreak: "keep-all",
              }}
            >
              {step.name}
            </div>
            {step.statusLabel && (
              <div
                style={{
                  fontSize: 10,
                  color: c.badge,
                  marginTop: 2,
                  lineHeight: 1.2,
                }}
              >
                {step.statusLabel}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

/* ─── ExpandableJourneySteps ────────────────────────────────────────────────── */

function ExpandableJourneySteps({ steps }: { steps: JStep[] }) {
  return (
    <div
      style={{
        borderTop: "1px solid #D0CEC9",
        borderBottom: "1px solid #D0CEC9",
        borderLeft: "1px solid #D0CEC9",
        borderRight: "1px solid #D0CEC9",
        borderRadius: 2,
        overflow: "hidden",
      }}
    >
      {steps.map((step, i) => {
        const c = stepColors(step.status)
        return (
          <details
            key={i}
            style={{
              backgroundColor: c.bg,
              borderTop: i > 0 ? "1px solid #D0CEC9" : "none",
            }}
          >
            <summary
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: 10,
                padding: "12px 14px",
                cursor: "pointer",
                listStyle: "none",
                userSelect: "none",
              }}
            >
              <span
                style={{
                  fontSize: 11,
                  fontFamily: "'DM Mono', monospace",
                  color: c.badge,
                  minWidth: 22,
                  flexShrink: 0,
                  marginTop: 2,
                }}
              >
                {step.status === "done" ? "✓" : `0${i + 1}`}
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "baseline",
                    flexWrap: "wrap",
                    gap: 6,
                    marginBottom: 2,
                  }}
                >
                  <span
                    style={{
                      fontSize: 13,
                      fontWeight:
                        step.status === "current" ||
                        step.status === "check-needed"
                          ? 700
                          : 600,
                      color: c.text,
                    }}
                  >
                    {step.name}
                  </span>
                  {step.statusLabel && (
                    <span
                      style={{
                        fontSize: 11,
                        color: c.badge,
                        fontWeight: 500,
                      }}
                    >
                      {step.statusLabel}
                    </span>
                  )}
                </div>
                <div style={{ fontSize: 11, color: c.badge, lineHeight: 1.4 }}>
                  {step.institution}
                </div>
              </div>
              <span
                aria-hidden="true"
                style={{
                  fontSize: 11,
                  color: c.badge,
                  flexShrink: 0,
                  marginTop: 2,
                }}
              >
                ▾
              </span>
            </summary>
            <div
              style={{
                padding: "0 14px 14px 46px",
              }}
            >
              <p
                style={{
                  fontSize: 12,
                  color: c.text,
                  lineHeight: 1.6,
                  marginBottom: step.detailLines.length ? 8 : 0,
                }}
              >
                {step.desc}
              </p>
              {step.detailLines.length > 0 && (
                <ul
                  style={{
                    margin: 0,
                    padding: 0,
                    listStyle: "none",
                    display: "flex",
                    flexDirection: "column",
                    gap: 4,
                  }}
                >
                  {step.detailLines.map((line, j) => (
                    <li
                      key={j}
                      style={{
                        fontSize: 12,
                        color: c.badge,
                        lineHeight: 1.6,
                        paddingLeft: 10,
                        borderLeft: `2px solid ${c.border}`,
                      }}
                    >
                      {line}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </details>
        )
      })}
    </div>
  )
}

/* ─── CopyButton ────────────────────────────────────────────────────────────── */

function CopyButton({ copyText }: { copyText: string }) {
  const [status, setStatus] = useState<"idle" | "success" | "fail">("idle")
  const [showFallback, setShowFallback] = useState(false)
  const fallbackRef = useRef<HTMLTextAreaElement>(null)

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(copyText)
      setStatus("success")
      setShowFallback(false)
    } catch {
      setStatus("fail")
      setShowFallback(true)
      setTimeout(() => {
        fallbackRef.current?.focus()
        fallbackRef.current?.select()
      }, 50)
    }
  }

  return (
    <div style={{ marginTop: 16 }}>
      <button
        type="button"
        onClick={handleCopy}
        style={{
          display: "inline-flex",
          alignItems: "center",
          minHeight: 44,
          padding: "10px 18px",
          border: "1.5px solid #1A1918",
          borderRadius: 2,
          backgroundColor: "transparent",
          color: "#1A1918",
          fontSize: 14,
          fontWeight: 600,
          cursor: "pointer",
          fontFamily: "inherit",
        }}
      >
        질문 복사하기
      </button>
      <div
        role="status"
        aria-live="polite"
        style={{ marginTop: 8, fontSize: 13 }}
      >
        {status === "success" && (
          <span style={{ color: "#166534" }}>
            내 상황과 질문을 복사했어요. 휴대폰 메모 등에 붙여 넣어 보관하세요.
          </span>
        )}
        {status === "fail" && (
          <span style={{ color: "#92400E" }}>
            자동 복사가 되지 않았어요. 아래 내용을 선택해 복사해 주세요.
          </span>
        )}
      </div>
      {showFallback && (
        <textarea
          ref={fallbackRef}
          readOnly
          value={copyText}
          aria-label="복사할 질문"
          onFocus={(e) => e.target.select()}
          rows={12}
          style={{
            display: "block",
            width: "100%",
            marginTop: 8,
            fontSize: 12,
            lineHeight: 1.7,
            padding: "10px 12px",
            fontFamily: "inherit",
            border: "1px solid #D0CEC9",
            borderRadius: 2,
            backgroundColor: "#FAFAF8",
            resize: "vertical",
            boxSizing: "border-box",
          }}
        />
      )}
    </div>
  )
}

/* ─── PreviousAnswer ────────────────────────────────────────────────────────── */

function PreviousAnswer({
  num,
  questionText,
  selectedLabel,
  onEdit,
}: {
  num: number
  questionText: string
  selectedLabel: string
  onEdit: () => void
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "flex-start",
        gap: 12,
        padding: "10px 14px",
        marginBottom: 8,
        borderTop: "1px solid #E8E6E1",
        borderBottom: "1px solid #E8E6E1",
        borderLeft: "1px solid #E8E6E1",
        borderRight: "1px solid #E8E6E1",
        borderRadius: 2,
        backgroundColor: "#F0EEE9",
      }}
    >
      <span
        style={{
          fontSize: 10,
          fontFamily: "'DM Mono', monospace",
          color: "#908D88",
          marginTop: 3,
          flexShrink: 0,
          minWidth: 28,
        }}
      >
        Q{String(num).padStart(2, "0")}
      </span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontSize: 11,
            color: "#908D88",
            marginBottom: 1,
            lineHeight: 1.3,
          }}
        >
          {questionText}
        </div>
        <div
          style={{
            fontSize: 13,
            color: "#1A1918",
            fontWeight: 500,
            lineHeight: 1.4,
          }}
        >
          {selectedLabel}
        </div>
      </div>
      <button
        type="button"
        onClick={onEdit}
        style={{
          fontSize: 12,
          color: "#1E3A8A",
          background: "none",
          border: "none",
          cursor: "pointer",
          fontFamily: "inherit",
          padding: "2px 0",
          minHeight: 44,
          flexShrink: 0,
          textDecoration: "underline",
          textDecorationStyle: "dotted",
        }}
      >
        변경
      </button>
    </div>
  )
}

/* ─── QuestionBlock ─────────────────────────────────────────────────────────── */

function QuestionBlock({
  num,
  question,
  desc,
  subtext,
  options,
  selected,
  onSelect,
}: {
  num: number
  question: string
  desc?: string
  subtext?: string
  options: { label: string; value: string }[]
  selected: string | null
  onSelect: (v: string) => void
}) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div
        style={{
          padding: "18px 20px",
          borderTop: "1.5px solid #1A1918",
          borderBottom: "1.5px solid #1A1918",
          borderLeft: "1.5px solid #1A1918",
          borderRight: "1.5px solid #1A1918",
          borderRadius: 2,
        }}
      >
        <p
          style={{
            fontSize: 10,
            color: "#908D88",
            marginBottom: 6,
            fontFamily: "'DM Mono', monospace",
            letterSpacing: "0.04em",
          }}
        >
          질문 {String(num).padStart(2, "0")}
        </p>
        <p
          style={{
            fontSize: 15,
            fontWeight: 700,
            color: "#1A1918",
            marginBottom: desc ? 8 : 14,
            lineHeight: 1.4,
            letterSpacing: "-0.01em",
          }}
        >
          {question}
        </p>
        {desc && (
          <p
            style={{
              fontSize: 13,
              color: "#4A4845",
              lineHeight: 1.6,
              marginBottom: 6,
            }}
          >
            {desc}
          </p>
        )}
        {subtext && (
          <p
            style={{
              fontSize: 12,
              color: "#908D88",
              lineHeight: 1.5,
              marginBottom: 14,
            }}
          >
            {subtext}
          </p>
        )}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {options.map((opt) => {
            const isSel = selected === opt.value
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => onSelect(opt.value)}
                aria-pressed={isSel}
                style={{
                  display: "block",
                  width: "100%",
                  minHeight: 44,
                  padding: "10px 14px",
                  textAlign: "left",
                  fontSize: 14,
                  color: isSel ? "#FAFAF8" : "#1A1918",
                  backgroundColor: isSel ? "#1A1918" : "#FAFAF8",
                  borderTop: isSel
                    ? "1.5px solid #1A1918"
                    : "1px solid #D0CEC9",
                  borderBottom: isSel
                    ? "1.5px solid #1A1918"
                    : "1px solid #D0CEC9",
                  borderLeft: isSel
                    ? "1.5px solid #1A1918"
                    : "1px solid #D0CEC9",
                  borderRight: isSel
                    ? "1.5px solid #1A1918"
                    : "1px solid #D0CEC9",
                  borderRadius: 2,
                  cursor: "pointer",
                  fontFamily: "inherit",
                  lineHeight: 1.4,
                  fontWeight: isSel ? 600 : 400,
                }}
              >
                {opt.label}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}

/* ─── ResultSection ─────────────────────────────────────────────────────────── */

function ResultSection({
  code,
  info,
  facts,
  journey,
  headingRef,
  onReset,
  onGoTo,
  overrideQ1,
}: {
  code: ResultCode
  info: ResultInfo
  facts: { label: string; value: string }[]
  journey: JStep[]
  headingRef: React.RefObject<HTMLHeadingElement | null>
  onReset: () => void
  onGoTo: (v: PageView) => void
  overrideQ1?: string | null
}) {
  const todayTasksRef = useRef<HTMLHeadingElement>(null)
  const effectiveQuestions =
    info.questions && overrideQ1
      ? [
          { text: overrideQ1, purpose: "추천 이유와 비교 대안을 확인해요." },
          ...info.questions.slice(1),
        ]
      : info.questions
  const effectiveInfo =
    effectiveQuestions !== info.questions
      ? { ...info, questions: effectiveQuestions }
      : info
  const copyText = buildCopyText(effectiveInfo, facts)
  const hasQuestions = !!info.questions
  const journeyNote = getJourneyNote(code)

  const prefersReduced =
    typeof window !== "undefined"
      ? window.matchMedia("(prefers-reduced-motion: reduce)").matches
      : false

  function scrollToTasks() {
    const el = todayTasksRef.current
    if (!el) return
    el.scrollIntoView({
      behavior: prefersReduced ? "auto" : "smooth",
      block: "start",
    })
    el.focus({ preventScroll: true })
  }

  return (
    <div style={{ marginTop: 28 }}>
      {/* Result heading — receives programmatic focus on first result appearance */}
      <div
        style={{
          borderTop: "2px solid #1A1918",
          paddingTop: 24,
          marginBottom: 20,
          scrollMarginTop: 80,
        }}
      >
        <h2
          ref={headingRef}
          tabIndex={-1}
          style={{
            fontSize: 20,
            fontWeight: 700,
            color: "#1A1918",
            letterSpacing: "-0.02em",
            marginBottom: 8,
            outline: "none",
          }}
        >
          {info.title}
        </h2>
        <p style={{ fontSize: 14, color: "#4A4845", lineHeight: 1.6 }}>
          {info.currentState}
        </p>
      </div>

      {/* Quick action banner */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: 12,
          padding: "14px 16px",
          backgroundColor: "#F0EEE9",
          borderRadius: 2,
          marginBottom: 24,
        }}
      >
        <span style={{ fontSize: 13, color: "#1A1918", lineHeight: 1.6 }}>
          <span style={{ color: "#908D88" }}>다음 행동: </span>
          <strong>{info.institution}</strong>
          {" · "}
          <span>{info.nextAction}</span>
        </span>
        <button
          type="button"
          onClick={scrollToTasks}
          style={{
            minHeight: 36,
            padding: "7px 14px",
            fontSize: 13,
            fontWeight: 600,
            color: "#1A1918",
            backgroundColor: "transparent",
            border: "1.5px solid #1A1918",
            borderRadius: 2,
            cursor: "pointer",
            fontFamily: "inherit",
            whiteSpace: "nowrap",
            flexShrink: 0,
          }}
        >
          지금 할 일 보기 ↓
        </button>
      </div>

      {/* Answer facts */}
      {facts.length > 0 && (
        <div style={{ marginBottom: 28 }}>
          <p
            style={{
              fontSize: 10,
              color: "#908D88",
              fontWeight: 600,
              letterSpacing: "0.06em",
              marginBottom: 10,
              textTransform: "uppercase",
            }}
          >
            답변 사실
          </p>
          <dl style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {facts.map((f, i) => (
              <div key={i} style={{ display: "flex", gap: 12 }}>
                <dt
                  style={{
                    fontSize: 13,
                    color: "#908D88",
                    minWidth: 84,
                    flexShrink: 0,
                  }}
                >
                  {f.label}
                </dt>
                <dd
                  style={{
                    fontSize: 13,
                    color: "#1A1918",
                    margin: 0,
                    lineHeight: 1.5,
                  }}
                >
                  {f.value}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      )}

      {/* Journey diagram */}
      <div style={{ marginBottom: 32 }}>
        <p
          style={{
            fontSize: 10,
            color: "#908D88",
            fontWeight: 600,
            letterSpacing: "0.06em",
            marginBottom: 6,
            textTransform: "uppercase",
          }}
        >
          전체 절차와 내 위치
        </p>
        {journeyNote && (
          <p
            style={{
              fontSize: 12,
              color: "#6B6864",
              lineHeight: 1.5,
              marginBottom: 10,
            }}
          >
            {journeyNote}
          </p>
        )}
        <ExpandableJourneySteps steps={journey} />
      </div>

      {/* 지금 할 일 */}
      <div
        style={{
          borderTop: "1px solid #D0CEC9",
          paddingTop: 24,
          marginBottom: 28,
          scrollMarginTop: 80,
        }}
      >
        <h3
          ref={todayTasksRef}
          id="today-tasks"
          tabIndex={-1}
          style={{
            fontSize: 16,
            fontWeight: 700,
            color: "#1A1918",
            marginBottom: 14,
            outline: "none",
          }}
        >
          지금 할 일
        </h3>
        <div
          style={{
            padding: "18px 18px",
            borderRadius: 2,
            marginBottom: info.centerNote ? 12 : 0,
            backgroundColor: "#FFFBEB",
            borderTop: "1px solid #FDE68A",
            borderBottom: "1px solid #FDE68A",
            borderLeft: "1px solid #FDE68A",
            borderRight: "1px solid #FDE68A",
          }}
        >
          <p
            style={{
              fontSize: 13,
              fontWeight: 700,
              color: "#78350F",
              marginBottom: 4,
            }}
          >
            먼저 확인할 곳
          </p>
          <p
            style={{
              fontSize: 15,
              fontWeight: 600,
              color: "#1A1918",
              marginBottom: 10,
              lineHeight: 1.4,
            }}
          >
            {info.institution}
          </p>
          <p
            style={{
              fontSize: 13,
              color: "#4A4845",
              lineHeight: 1.7,
              marginBottom: info.contactQuestion ? 14 : 0,
            }}
          >
            {info.nextAction}
          </p>
          {info.contactQuestion && (
            <>
              <p
                style={{
                  fontSize: 11,
                  fontWeight: 600,
                  color: "#92400E",
                  marginBottom: 6,
                  letterSpacing: "0.02em",
                }}
              >
                이렇게 물어보세요
              </p>
              <p
                style={{
                  fontSize: 13,
                  color: "#1A1918",
                  lineHeight: 1.7,
                  fontStyle: "italic",
                  padding: "10px 14px",
                  backgroundColor: "#FEF9C3",
                  borderRadius: 2,
                  borderTop: "1px solid #FDE68A",
                  borderBottom: "1px solid #FDE68A",
                  borderLeft: "1px solid #FDE68A",
                  borderRight: "1px solid #FDE68A",
                }}
              >
                "{info.contactQuestion}"
              </p>
            </>
          )}
          {info.onlineLink && (
            <div style={{ marginTop: 12 }}>
              <a
                href="https://www.nhis.or.kr/nhis/minwon/retrieveCvaplCstInfoColctAgreView.do"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 4,
                  fontSize: 13,
                  color: "#1E3A8A",
                  textDecoration: "underline",
                  fontWeight: 600,
                }}
              >
                공단 온라인 개인 상담 (로그인 · 새 탭)
              </a>
              <p
                style={{
                  fontSize: 12,
                  color: "#6B6864",
                  lineHeight: 1.5,
                  marginTop: 4,
                }}
              >
                전화 대신 글로 문의할 수 있어요. 공단 홈페이지의 '국민소통·참여
                → 온라인 상담문의 → 개인 상담'에서도 찾을 수 있어요.
              </p>
            </div>
          )}
          {info.secondary && (
            <p
              style={{
                fontSize: 13,
                color: "#78350F",
                lineHeight: 1.6,
                marginTop: 12,
                paddingTop: 10,
                borderTop: "1px solid #FDE68A",
              }}
            >
              추가 확인: {info.secondary}
            </p>
          )}
        </div>
        {info.centerNote && (
          <div style={{ marginTop: 10 }}>
            <p
              style={{
                fontSize: 11,
                fontWeight: 600,
                color: "#908D88",
                letterSpacing: "0.04em",
                marginBottom: 4,
              }}
            >
              센터 상담에서 도움받을 일
            </p>
            <p style={{ fontSize: 13, color: "#908D88", lineHeight: 1.6 }}>
              {info.centerNote}
            </p>
          </div>
        )}
      </div>

      {/* 센터에서 물어볼 질문 3개 */}
      <div style={{ marginBottom: 28 }}>
        <h3
          style={{
            fontSize: 16,
            fontWeight: 700,
            color: "#1A1918",
            marginBottom: 14,
          }}
        >
          센터에서 물어볼 질문 3개
        </h3>
        {hasQuestions ? (
          <>
            {overrideQ1 && (
              <p style={{ fontSize: 12, color: "#1E3A8A", marginBottom: 8 }}>
                선택한 제품이 반영됐어요.{" "}
                <button
                  type="button"
                  onClick={() => onGoTo("product")}
                  style={{
                    fontSize: 12,
                    color: "#1E3A8A",
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    fontFamily: "inherit",
                    padding: 0,
                    textDecoration: "underline",
                  }}
                >
                  제품 변경 →
                </button>
              </p>
            )}
            <ol
              style={{
                listStyle: "none",
                padding: 0,
                margin: 0,
                display: "flex",
                flexDirection: "column",
                gap: 10,
              }}
            >
              {effectiveInfo.questions!.map((q, i) => (
                <li
                  key={i}
                  style={{
                    padding: "14px 16px",
                    borderTop: "1px solid #D0CEC9",
                    borderBottom: "1px solid #D0CEC9",
                    borderLeft: "1px solid #D0CEC9",
                    borderRight: "1px solid #D0CEC9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 14,
                      color: "#1A1918",
                      lineHeight: 1.6,
                      marginBottom: 6,
                    }}
                  >
                    <span style={{ fontWeight: 700, marginRight: 6 }}>
                      {i + 1}.
                    </span>
                    {q.text}
                  </p>
                  <p
                    style={{ fontSize: 12, color: "#908D88", lineHeight: 1.5 }}
                  >
                    확인할 것: {q.purpose}
                  </p>
                </li>
              ))}
            </ol>
            {copyText && <CopyButton copyText={copyText} />}
          </>
        ) : (
          <p
            style={{
              fontSize: 13,
              color: "#908D88",
              lineHeight: 1.6,
              padding: "12px 16px",
              border: "1px solid #E8E6E1",
              borderRadius: 2,
            }}
          >
            이 결과의 상담 준비 질문을 불러올 수 없어요.
          </p>
        )}
      </div>

      {/* Health detail — R08/R09/R10 only */}
      {info.hasHealthDetail && (
        <div
          style={{
            borderTop: "1px solid #D0CEC9",
            paddingTop: 24,
            marginBottom: 32,
          }}
        >
          <h3
            style={{
              fontSize: 15,
              fontWeight: 700,
              color: "#1A1918",
              marginBottom: 4,
            }}
          >
            건강보험 지원 금액 안내
          </h3>
          {(code === "R09" || code === "R10") && (
            <p
              style={{
                fontSize: 12,
                color: "#92400E",
                lineHeight: 1.5,
                marginBottom: 10,
                padding: "8px 12px",
                backgroundColor: "#FFFBEB",
                borderRadius: 2,
              }}
            >
              아래는 일반 기준이에요. 이번에 지원받을 수 있는지는 이전 이력을
              확인한 뒤 알 수 있어요.
            </p>
          )}
          <p
            style={{
              fontSize: 13,
              color: "#1A1918",
              marginBottom: 6,
              lineHeight: 1.6,
            }}
          >
            한쪽 보청기 기준으로, 처음 청구 기준액 111만 원(제품 91만 원 + 초기
            관리 20만 원)과 이후 적합관리 기준액 20만 원(연 5만 원 × 최대 4회)을
            합쳐 전체 기준액 131만 원이에요.
          </p>
          <details
            style={{
              marginTop: 12,
              marginBottom: 12,
              background: "#f3f6fb",
              border: "1px solid #dce3ed",
              borderRadius: 8,
            }}
          >
            <summary
              style={{
                padding: "12px 14px",
                fontSize: 14,
                fontWeight: 600,
                lineHeight: 1.6,
                color: "#1a1918",
                cursor: "pointer",
                userSelect: "none",
              }}
            >
              지원 금액과 지급 조건 자세히 보기
            </summary>
            <div
              style={{
                padding: "0 14px 16px 28px",
                fontSize: 14,
                color: "#4a4845",
                lineHeight: 1.8,
                overflowWrap: "anywhere",
              }}
            >
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  marginBottom: 10,
                  lineHeight: 1.5,
                }}
              >
                최종 급여 자격을 판정하는 내용이 아닙니다. 개인별 적용은
                공단에서 확인하세요.
              </p>
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginBottom: 14,
                }}
              >
                기준액은 지원액 계산 한도예요. 기준액이 그대로 지급되는 것은
                아니에요. 자격별 최대 지원액을 확인하세요.
              </p>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                  marginBottom: 10,
                }}
              >
                <div
                  style={{
                    padding: "12px 16px",
                    border: "1px solid #D0CEC9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 2,
                      letterSpacing: "0.04em",
                    }}
                  >
                    지원금 계산 기준 · 처음 청구 기준액 111만 원
                  </p>
                  <p
                    style={{
                      fontSize: 11,
                      color: "#6B6864",
                      lineHeight: 1.4,
                      marginBottom: 8,
                    }}
                  >
                    제품 91만 원 + 초기 관리 20만 원 · 구입 후 1개월 경과 및
                    병원 검수 후 청구해요.
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                      gap: 8,
                      flexWrap: "wrap",
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      건강보험 일반 대상 · 90%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      최대 99만 9천 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "baseline",
                      gap: 6,
                      flexWrap: "wrap",
                      marginBottom: 0,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      차상위 본인부담경감 대상자 · 100%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      최대 111만 원
                    </strong>
                  </div>
                </div>
                <div
                  style={{
                    padding: "12px 16px",
                    border: "1px solid #D0CEC9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 2,
                      letterSpacing: "0.04em",
                    }}
                  >
                    관리비 계산 기준 · 이후 청구 연 5만 원 × 최대 4회
                  </p>
                  <p
                    style={{
                      fontSize: 11,
                      color: "#6B6864",
                      lineHeight: 1.4,
                      marginBottom: 8,
                    }}
                  >
                    기준액 합계 20만 원 · 구입 1년 후부터 5년까지, 매년 실제
                    관리 후 따로 청구해요.
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                      gap: 8,
                      flexWrap: "wrap",
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      건강보험 일반 대상 · 90%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      연 최대 4만 5천 원 / 4회 합계 18만 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "baseline",
                      gap: 6,
                      flexWrap: "wrap",
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      차상위 본인부담경감 대상자 · 100%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      연 최대 5만 원 / 4회 합계 20만 원
                    </strong>
                  </div>
                </div>
                <div
                  style={{
                    padding: "12px 16px",
                    backgroundColor: "#F0EEE9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 2,
                      letterSpacing: "0.04em",
                    }}
                  >
                    전체 지원금 계산 기준 · 전체 기준액 131만 원
                  </p>
                  <p
                    style={{
                      fontSize: 11,
                      color: "#6B6864",
                      lineHeight: 1.4,
                      marginBottom: 8,
                    }}
                  >
                    처음 청구와 이후 관리 비용을 합한 금액이며, 한 번에 지급되는
                    돈은 아니에요.
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                      gap: 8,
                      flexWrap: "wrap",
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      건강보험 일반 대상 · 90%
                    </span>
                    <strong style={{ fontSize: 15, color: "#1A1918" }}>
                      총 최대 117만 9천 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "baseline",
                      gap: 6,
                      flexWrap: "wrap",
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      차상위 본인부담경감 대상자 · 100%
                    </span>
                    <strong style={{ fontSize: 15, color: "#1A1918" }}>
                      총 최대 131만 원
                    </strong>
                  </div>
                </div>
              </div>
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  차상위 본인부담경감 대상자란?
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  <p style={{ marginBottom: 6 }}>
                    소득·재산, 부양 요건과 질환·연령 등의 기준을 심사받아,
                    건강보험 의료비의 본인부담을 줄여주는 지원 대상으로 인정된
                    분이에요.
                  </p>
                  <p style={{ marginBottom: 6 }}>
                    청각장애 등록만으로 자동 적용되지는 않아요. 의료급여와는
                    다른 건강보험의 지원 제도예요.
                  </p>
                  <p>
                    대상인지 모르겠다면 국민건강보험공단에 "제가 차상위
                    본인부담경감 대상자로 등록되어 있나요?"라고 확인해 주세요.
                  </p>
                </div>
              </details>
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  구입 후 병원 확인·청구·관리는 어떻게 이어지나요?
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  구입 후 1개월이 지난 뒤 이비인후과에서 착용 효과
                  확인(검수확인)을 받고 지원금을 청구해요. 청구는 판매업소에
                  위임하거나 직접 공단에 청구할 수 있어요. 이후 구입 1년 후부터
                  5년까지 매년 1회 이상 실제 관리를 받은 뒤 후기 관리비를
                  청구해요. 날짜가 지난다고 자동 입금되는 방식이 아니에요.
                  개인별 청구 가능일과 계좌는 판매업소·공단에 확인하세요.
                </div>
              </details>
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  내 지급액이 안내된 최대 금액과 달라질 수 있나요?
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  <p style={{ marginBottom: 8 }}>
                    건강보험은 기본적으로 지급기준금액의 90%를 지원해요. 제품의
                    고시가격이나 실제 구입가격이 낮으면 지원액도 줄어들 수
                    있어요. 후기 관리도 실제 비용과 지급 조건을 확인해야 해요.
                  </p>
                  <p style={{ marginBottom: 8 }}>
                    차상위 본인부담경감 대상 등은 같은 건강보험 안에서 100%
                    지원이 적용돼요. 기준을 넘는 비용까지 모두 지원한다는 뜻은
                    아니에요. 본인의 경감 적용 여부는 국민건강보험공단에서
                    확인하세요.
                  </p>
                  <p>
                    제품별 고시가격에는 초기 관리비가 이미 포함되어 있어요.
                    고시가격에 20만 원을 다시 더하지 않아요.
                  </p>
                </div>
              </details>
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  직접 청구한다면 서류는 어디서 받나요?
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  병원에서 지원금 신청용 보청기 처방전·검사 자료와 구입 후
                  검수확인서를 받아요. 판매업소에서 구매 계약서·영수증 등 구입
                  증빙과 제품 바코드 확인 자료를 받아요. 위임 청구 시에는
                  위임장·신분증 사본 등 본인이 제공할 자료를 판매업소에
                  안내받으세요.
                </div>
              </details>
            </div>
          </details>
        </div>
      )}

      {/* Navigation to reference/bilateral/product */}
      <div
        style={{
          borderTop: "1px solid #E8E6E1",
          paddingTop: 20,
          marginBottom: 16,
        }}
      >
        <p
          style={{
            fontSize: 11,
            fontWeight: 600,
            color: "#908D88",
            marginBottom: 10,
            letterSpacing: "0.06em",
            textTransform: "uppercase",
          }}
        >
          더 알아보기
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          <button
            type="button"
            onClick={() => onGoTo("reference")}
            style={{
              minHeight: 44,
              padding: "10px 16px",
              fontSize: 13,
              color: "#1A1918",
              backgroundColor: "transparent",
              border: "1px solid #D0CEC9",
              borderRadius: 2,
              cursor: "pointer",
              fontFamily: "inherit",
            }}
          >
            전체 기준 보기
          </button>
          <button
            type="button"
            onClick={() => onGoTo("bilateral")}
            style={{
              minHeight: 44,
              padding: "10px 16px",
              fontSize: 13,
              color: "#1A1918",
              backgroundColor: "transparent",
              border: "1px solid #D0CEC9",
              borderRadius: 2,
              cursor: "pointer",
              fontFamily: "inherit",
            }}
          >
            아동·청소년 양쪽 지원
          </button>
          <button
            type="button"
            onClick={() => onGoTo("product")}
            style={{
              minHeight: 44,
              padding: "10px 16px",
              fontSize: 13,
              color: "#1A1918",
              backgroundColor: "transparent",
              border: "1px solid #D0CEC9",
              borderRadius: 2,
              cursor: "pointer",
              fontFamily: "inherit",
            }}
          >
            센터·제품 등록 확인
          </button>
        </div>
      </div>

      {/* Reset */}
      <div style={{ borderTop: "1px solid #E8E6E1", paddingTop: 16 }}>
        <button
          type="button"
          onClick={onReset}
          style={{
            fontSize: 13,
            color: "#908D88",
            background: "none",
            border: "none",
            cursor: "pointer",
            padding: "8px 0",
            fontFamily: "inherit",
            textDecoration: "underline",
            textDecorationStyle: "dotted",
            minHeight: 44,
          }}
        >
          처음부터 확인하기
        </button>
      </div>
    </div>
  )
}

/* ─── Main component ────────────────────────────────────────────────────────── */

type NavEntry = { view: PageView; scrollY: number; openDetailIds: string[]; focusId: string | null }

export default function HearingAidGuide() {
  const [view, setView] = useState<PageView>("summary")
  const [navStack, setNavStack] = useState<NavEntry[]>([])
  const [q1, setQ1] = useState<Q1 | null>(null)
  const [q2, setQ2] = useState<Q2 | null>(null)
  const [q3, setQ3] = useState<Q3 | null>(null)
  const [q4, setQ4] = useState<Q4 | null>(null)
  const [q5, setQ5] = useState<Q5 | null>(null)
  const [productQuery, setProductQuery] = useState("")
  const [productResults, setProductResults] = useState<Product[]>([])
  const [productPage, setProductPage] = useState(0)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [productSearched, setProductSearched] = useState(false)

  const guidedHeadingRef = useRef<HTMLHeadingElement>(null)
  const resultHeadingRef = useRef<HTMLHeadingElement>(null)
  const prevResultRef = useRef<ResultCode | null>(null)
  const bilateralQsRef = useRef<HTMLHeadingElement>(null)

  /* Open bilateral view when page loads with #one-or-two hash */
  useEffect(() => {
    if (window.location.hash === "#one-or-two") {
      setView("bilateral")
    }
  }, [])

  const currentStep = getCurrentStep(q1, q2, q3, q4, q5)
  const resultCode =
    currentStep === "done" ? computeResult(q1, q2, q3, q4, q5) : null
  const lastAnsweredQ = getLastAnsweredQ(q1, q2, q3, q4, q5)
  const topBarSteps = computeTopBarSteps(q1, q2, q3, q4, currentStep, q5)

  const showQ2 = q1 === "registered"
  const showQ3 = q1 === "registered" && q2 !== null
  const showQ4 = showQ3 && q2 !== "medical-aid" && q3 === "yes"
  const showQ5 = q1 === "registered" && q2 === "medical-aid" && q3 === "yes"

  const q1Label = Q1_OPTS.find((o) => o.value === q1)?.label ?? ""
  const q2Label = Q2_OPTS.find((o) => o.value === q2)?.label ?? ""
  const q3Label = Q3_OPTS.find((o) => o.value === q3)?.label ?? ""
  const q4Label = Q4_OPTS.find((o) => o.value === q4)?.label ?? ""
  const q5Label = Q5_OPTS.find((o) => o.value === q5)?.label ?? ""

  function handleQ1(v: string) {
    setQ1(v as Q1)
    setQ2(null)
    setQ3(null)
    setQ4(null)
    setQ5(null)
  }
  function handleQ2(v: string) {
    setQ2(v as Q2)
    setQ3(null)
    setQ4(null)
    setQ5(null)
  }
  function handleQ3(v: string) {
    setQ3(v as Q3)
    setQ4(null)
    setQ5(null)
  }
  function handleQ4(v: string) {
    setQ4(v as Q4)
  }
  function handleQ5(v: string) {
    setQ5(v as Q5)
  }

  const prefersReduced =
    typeof window !== "undefined"
      ? window.matchMedia("(prefers-reduced-motion: reduce)").matches
      : false

  /* Scroll/focus result heading only when transitioning from no-result to first result */
  useEffect(() => {
    if (resultCode !== null && prevResultRef.current === null) {
      const el = resultHeadingRef.current
      if (el) {
        const delay = prefersReduced ? 0 : 50
        setTimeout(() => {
          el.scrollIntoView({
            behavior: prefersReduced ? "auto" : "smooth",
            block: "nearest",
          })
        }, delay)
        setTimeout(
          () => el.focus({ preventScroll: true }),
          prefersReduced ? delay : 350,
        )
      }
    }
    prevResultRef.current = resultCode
  }, [resultCode, prefersReduced])

  function handleReset() {
    setQ1(null)
    setQ2(null)
    setQ3(null)
    setQ4(null)
    setQ5(null)
    window.scrollTo({ top: 0, behavior: prefersReduced ? "auto" : "smooth" })
    setTimeout(() => guidedHeadingRef.current?.focus(), prefersReduced ? 0 : 50)
  }

  function enterGuided() {
    setView("guided")
    window.scrollTo({ top: 0 })
  }

  function goTo(v: PageView, triggerId?: string) {
    const openDetailIds = Array.from(
      document.querySelectorAll<HTMLDetailsElement>("details[id][open]"),
    ).map((d) => d.id)
    setNavStack((prev) => [
      ...prev,
      { view, scrollY: window.scrollY, openDetailIds, focusId: triggerId ?? null },
    ])
    setView(v)
    window.scrollTo({ top: 0 })
  }

  function backLabel(): string {
    if (navStack.length === 0) {
      return resultCode
        ? "← 내 확인 결과로 돌아가기"
        : "← 30초 요약으로 돌아가기"
    }
    const prev = navStack[navStack.length - 1]
    if (prev.view === "reference") return "← 전체 기준의 보던 곳으로 돌아가기"
    if (prev.view === "guided") return "← 내 확인 결과로 돌아가기"
    return "← 30초 요약으로 돌아가기"
  }

  function goBackFromInner() {
    if (navStack.length > 0) {
      const prev = navStack[navStack.length - 1]
      setNavStack((s) => s.slice(0, -1))
      setView(prev.view)
      const delay = prefersReduced ? 0 : 80
      setTimeout(() => {
        // Restore open details
        prev.openDetailIds.forEach((id) => {
          const el = document.getElementById(id) as HTMLDetailsElement | null
          if (el && el.tagName === "DETAILS") el.open = true
        })
        // Restore scroll (after details open, so layout is correct)
        requestAnimationFrame(() => {
          window.scrollTo({ top: prev.scrollY })
          // Restore focus
          setTimeout(() => {
            if (prev.focusId) {
              const focusEl = document.getElementById(prev.focusId)
              if (focusEl) {
                focusEl.focus({ preventScroll: true })
                return
              }
            }
            if (prev.view === "guided" && resultCode)
              resultHeadingRef.current?.focus()
            else if (prev.view === "guided")
              guidedHeadingRef.current?.focus()
          }, prefersReduced ? 0 : 40)
        })
      }, delay)
    } else {
      const target = resultCode ? "guided" : "summary"
      setView(target)
      window.scrollTo({ top: 0 })
      setTimeout(
        () => {
          if (target === "guided" && resultCode)
            resultHeadingRef.current?.focus()
          else guidedHeadingRef.current?.focus()
        },
        prefersReduced ? 0 : 80,
      )
    }
  }

  function handleProductSearch() {
    setSelectedProduct(null)
    if (!productQuery.trim()) {
      setProductSearched(false)
      setProductResults([])
      return
    }
    const results = searchProducts(productQuery)
    setProductResults(results)
    setProductPage(0)
    setProductSearched(true)
  }

  const CHECKED_AT = PRODUCTS_META.checkedAt
  const STALE_DATE = new Date("2026-09-30T00:00:00+09:00")
  const isDataStale = new Date() >= STALE_DATE

  const r08ModelQuestion = useMemo(() => {
    if (!selectedProduct || isDataStale) return null
    return `${selectedProduct.model}을 제게 추천하는 이유와 비교할 수 있는 다른 제품은 무엇인가요?`
  }, [selectedProduct, isDataStale])

  const inner: React.CSSProperties = { maxWidth: 720, margin: "0 auto" }

  /* Q display helpers — last answered Q stays open with options visible */
  const q1IsOpen = currentStep === "Q1" || lastAnsweredQ === "Q1"
  const q1IsCollapsed = q1 !== null && !q1IsOpen
  const q2IsOpen = showQ2 && (currentStep === "Q2" || lastAnsweredQ === "Q2")
  const q2IsCollapsed = showQ2 && q2 !== null && !q2IsOpen
  const q3IsOpen = showQ3 && (currentStep === "Q3" || lastAnsweredQ === "Q3")
  const q3IsCollapsed = showQ3 && q3 !== null && !q3IsOpen
  const q4IsOpen = showQ4 && (currentStep === "Q4" || lastAnsweredQ === "Q4")
  const q4IsCollapsed = showQ4 && q4 !== null && !q4IsOpen
  const q5IsOpen = showQ5 && (currentStep === "Q5" || lastAnsweredQ === "Q5")
  const q5IsCollapsed = showQ5 && q5 !== null && !q5IsOpen

  return (
    <main id="main-content">
      {/* Screen-reader live region for result changes */}
      <div
        role="status"
        aria-live="polite"
        aria-atomic="true"
        style={{
          position: "absolute",
          width: 1,
          height: 1,
          overflow: "hidden",
          clip: "rect(0,0,0,0)",
          whiteSpace: "nowrap",
        }}
      >
        {resultCode
          ? `결과가 업데이트됐어요: ${RESULT_INFO[resultCode].title}`
          : ""}
      </div>

      <div
        className="px-4 sm:px-6"
        style={{ paddingTop: 28, paddingBottom: 64 }}
      >
        {/* Breadcrumb */}
        <div style={{ ...inner, marginBottom: 20 }}>
          <nav aria-label="현재 위치">
            <ol
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                listStyle: "none",
                padding: 0,
                margin: 0,
                fontSize: 12,
                color: "#908D88",
              }}
            >
              <li>
                <Link
                  to="/welfare"
                  style={{ color: "#1E3A8A", textDecoration: "none" }}
                >
                  복지·지원정보
                </Link>
              </li>
              <li aria-hidden="true">›</li>
              <li aria-current="page">보청기 건강보험 지원 안내</li>
            </ol>
          </nav>
        </div>

        {/* ── Summary ── */}
        {view === "summary" && (
          <div style={inner}>
            <h1
              style={{
                fontSize: 22,
                fontWeight: 700,
                color: "#1A1918",
                letterSpacing: "-0.02em",
                lineHeight: 1.3,
                marginBottom: 12,
              }}
            >
              보청기센터에 가기 전,
              <br />
              지원 과정부터 알아보세요
            </h1>
            <p
              style={{
                fontSize: 14,
                color: "#4A4845",
                lineHeight: 1.7,
                marginBottom: 24,
              }}
            >
              청각장애 검사 중이거나 등록 결과를 기다리고 있어도 괜찮아요.
              <br />
              전체 과정에서 내 위치를 알아보고, 센터에서 물어볼 질문을
              준비하세요.
            </p>

            <div
              style={{
                padding: "16px 18px",
                backgroundColor: "#F0EEE9",
                borderRadius: 2,
                marginBottom: 20,
              }}
            >
              <p
                style={{
                  fontSize: 10,
                  color: "#908D88",
                  fontWeight: 600,
                  letterSpacing: "0.06em",
                  marginBottom: 12,
                  textTransform: "uppercase",
                }}
              >
                30초 요약
              </p>
              <ul
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: 0,
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                }}
              >
                {[
                  "등록 확인 → 처방 → 구입·착용 → 검수·청구 → 이후 관리로 이어져요.",
                  "센터에서는 제품 상담과 신청 지원 범위를 물어보세요.",
                  "한쪽 지원 기준액 131만 원은 제품·관리 비용을 나누어 지원하는 구조예요.",
                ].map((item, i) => (
                  <li
                    key={i}
                    style={{
                      display: "flex",
                      gap: 8,
                      fontSize: 13,
                      color: "#1A1918",
                      lineHeight: 1.5,
                    }}
                  >
                    <span
                      style={{
                        color: "#908D88",
                        flexShrink: 0,
                        fontFamily: "'DM Mono', monospace",
                        fontSize: 11,
                        marginTop: 1,
                      }}
                    >
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <p
              style={{
                fontSize: 12,
                color: "#908D88",
                lineHeight: 1.6,
                marginBottom: 28,
                padding: "10px 14px",
                border: "1px solid #E8E6E1",
                borderRadius: 2,
              }}
            >
              최종 급여 자격을 판정하는 페이지가 아닙니다. 개인별 적용은
              공단에서 확인하세요.
            </p>

            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <button
                type="button"
                onClick={enterGuided}
                style={{
                  minHeight: 52,
                  padding: "14px 24px",
                  fontSize: 15,
                  fontWeight: 700,
                  color: "#FAFAF8",
                  backgroundColor: "#1A1918",
                  border: "none",
                  borderRadius: 2,
                  cursor: "pointer",
                  fontFamily: "inherit",
                  letterSpacing: "-0.01em",
                  textAlign: "left",
                }}
              >
                내 상황 확인하기 →
              </button>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                <button
                  type="button"
                  onClick={() => goTo("reference")}
                  style={{
                    minHeight: 44,
                    padding: "10px 18px",
                    fontSize: 13,
                    color: "#1A1918",
                    backgroundColor: "transparent",
                    border: "1.5px solid #D0CEC9",
                    borderRadius: 2,
                    cursor: "pointer",
                    fontFamily: "inherit",
                  }}
                >
                  전체 기준 보기
                </button>
                <button
                  type="button"
                  onClick={() => goTo("bilateral")}
                  style={{
                    minHeight: 44,
                    padding: "10px 18px",
                    fontSize: 13,
                    color: "#1A1918",
                    backgroundColor: "transparent",
                    border: "1.5px solid #D0CEC9",
                    borderRadius: 2,
                    cursor: "pointer",
                    fontFamily: "inherit",
                  }}
                >
                  아동·청소년의 양쪽 지원 알아보기
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ── Reference (전체 기준) ── */}
        {view === "reference" && (
          <div style={inner}>
            <button
              type="button"
              onClick={goBackFromInner}
              style={{
                fontSize: 13,
                color: "#1E3A8A",
                background: "none",
                border: "none",
                cursor: "pointer",
                fontFamily: "inherit",
                padding: "0 0 20px",
                minHeight: 44,
              }}
            >
              {backLabel()}
            </button>
            <h2
              id="full-criteria"
              style={{
                fontSize: 20,
                fontWeight: 700,
                color: "#1A1918",
                marginBottom: 8,
                letterSpacing: "-0.02em",
              }}
            >
              전체 기준 보기
            </h2>
            <p
              style={{
                fontSize: 13,
                color: "#908D88",
                lineHeight: 1.6,
                marginBottom: 28,
              }}
            >
              이 안내는 읽기용 참고 화면이에요. 내 상황별 다음 행동을 확인하려면
              '내 상황 확인하기'를 이용하세요.
            </p>

            {/* 목차 */}
            <nav
              aria-label="전체 기준 목차"
              style={{
                marginBottom: 32,
                padding: "14px 16px",
                border: "1px solid #E8E6E1",
                borderRadius: 2,
              }}
            >
              <p
                style={{
                  fontSize: 11,
                  fontWeight: 600,
                  color: "#908D88",
                  marginBottom: 8,
                  letterSpacing: "0.06em",
                  textTransform: "uppercase",
                }}
              >
                목차
              </p>
              <ol
                style={{
                  margin: 0,
                  padding: 0,
                  listStyle: "none",
                  display: "flex",
                  flexDirection: "column",
                  gap: 4,
                }}
              >
                {[
                  ["#registration-help", "청각장애 등록"],
                  ["#eligibility", "지원 대상"],
                  ["#one-or-two", "아동·청소년 양쪽 지원"],
                  ["#benefit", "지원 금액"],
                  ["#steps", "5단계 진행 절차"],
                  ["#center-product-check", "구입 전 센터·제품 등록 확인"],
                  ["#before-buying", "센터 상담 준비"],
                  ["#sources", "공식 출처"],
                ].map(([href, label]) => (
                  <li key={href}>
                    <a
                      href={href}
                      style={{
                        fontSize: 13,
                        color: "#1E3A8A",
                        textDecoration: "underline",
                        textDecorationStyle: "dotted",
                      }}
                    >
                      {label}
                    </a>
                  </li>
                ))}
              </ol>
            </nav>

            {/* 1. 청각장애 등록 */}
            <section id="registration-help" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                청각장애 등록
              </h3>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 10,
                }}
              >
                병원에서 난청 진단을 받는 것과 청각장애 등록은 달라요. 진단
                자료를 제출하고 심사를 거치는 행정 절차예요.
              </p>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 10,
                }}
              >
                처음이면 주소지 주민센터에서 신청 방법과 진단받을 병원을
                안내받으세요. <br /> 이미 진단 자료가 있다면 제출 가능 여부를
                확인하세요.
              </p>
              <div style={{ marginTop: 20, marginBottom: 20 }}>
                <p
                  style={{
                    fontSize: 14,
                    fontWeight: 600,
                    marginBottom: 12,
                  }}
                >
                  청각장애 등록은 이렇게 진행돼요
                </p>

                <ol
                  className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4"
                  style={{
                    listStyle: "none",
                    padding: 0,
                    margin: 0,
                  }}
                >
                  {[
                    {
                      icon: "🏥",
                      title: "검사·진단",
                      institution: "이비인후과",
                    },
                    {
                      icon: "📄",
                      title: "등록 신청·자료 제출",
                      institution: "주소지 주민센터",
                    },
                    {
                      icon: "🔎",
                      title: "장애정도 심사",
                      institution: "국민연금공단",
                    },
                    {
                      icon: "✅",
                      title: "등록 결과 확인",
                      institution: "주민센터",
                    },
                  ].map((step, index) => (
                    <li
                      key={step.title}
                      style={{
                        padding: 16,
                        border: "1px solid #d0cec9",
                        borderRadius: 8,
                        backgroundColor: "#fafaf8",
                      }}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          display: "block",
                          fontSize: 26,
                          marginBottom: 10,
                        }}
                      >
                        {step.icon}
                      </span>

                      <p
                        style={{
                          fontSize: 12,
                          color: "#666",
                          marginBottom: 4,
                        }}
                      >
                        {index + 1}단계
                      </p>

                      <p
                        style={{
                          fontSize: 14,
                          fontWeight: 600,
                          lineHeight: 1.5,
                          marginBottom: 6,
                        }}
                      >
                        {step.title}
                      </p>

                      <p
                        style={{
                          fontSize: 13,
                          color: "#4a4845",
                          margin: 0,
                        }}
                      >
                        {step.institution}
                      </p>
                    </li>
                  ))}
                </ol>
              </div>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  padding: "12px 14px",
                  backgroundColor: "#F0EEE9",
                  borderRadius: 2,
                }}
              >
                문의 예:{" "}
                <em>
                  "청각장애 등록을 처음 신청하려고 해요. 어떤 병원 검사와 서류가
                  필요한가요?"
                </em>
              </p>
            </section>

            {/* 2. 지원 대상 */}
            <section id="eligibility" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                건강보험 보청기 지원 대상
              </h3>
              <div
                style={{
                  fontSize: 14,
                  color: "#4a4845",
                  lineHeight: 1.7,
                }}
              >
                <p style={{ marginBottom: 6 }}>
                  아래 두 조건에 모두 해당해야 해요.
                </p>

                <ul
                  style={{
                    listStyleType: "disc",
                    paddingLeft: 20,
                    margin: "0 0 18px",
                  }}
                >
                  <li>청력장애로 등록된 청각장애인</li>
                  <li>건강보험 가입자 또는 피부양자</li>
                </ul>

                <p style={{ fontWeight: 600, marginBottom: 6 }}>
                  지원받으려면 다음 절차도 필요해요.
                </p>

                <ul
                  style={{
                    listStyleType: "disc",
                    paddingLeft: 20,
                    margin: 0,
                  }}
                >
                  <li style={{ marginBottom: 6 }}>
                    <strong>병원 처방:</strong> 전문의의 보청기 필요 판단과
                    지원금 신청용 처방전
                  </li>
                  <li style={{ marginBottom: 6 }}>
                    <strong>제품 구입:</strong> 급여 등록 제품·판매업소 확인
                  </li>
                  <li>
                    <strong>구입 후:</strong> 검수확인과 지원금 청구
                  </li>
                </ul>
              </div>

              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  예전에 지원받았다면 언제 다시 받을 수 있나요?
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  보청기의 내구연한은 5년이에요. 지원받은 기기를 사용하는 기간의
                  기준으로, 5년마다 자동 입금된다는 뜻은 아니에요. 새 구입 전
                  공단에 이전 구입·급여 이력과 다시 지원받을 시점을 확인하세요.
                  <div
                    style={{
                      marginTop: 12,
                      marginBottom: 8,
                      padding: "12px 14px",
                      background: "#efeeea",
                      borderRadius: 6,
                    }}
                  >
                    <strong>이렇게 물어보세요</strong>
                    <p style={{ margin: "4px 0 0" }}>
                      “이전에 보청기 건강보험 지원을 받은 기록과 지원받은 날짜,
                      이번 신청 전에 확인할 조건을 알려주세요.”
                    </p>
                  </div>
                  <a
                    href="https://www.nhis.or.kr/nhis/minwon/retrieveCvaplCstInfoColctAgreView.do"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      minHeight: 44,
                      color: "#1e3a8a",
                      textDecoration: "underline",
                      textUnderlineOffset: 3,
                    }}
                  >
                    이전 지원 기록 문의하기 ↗ (로그인 · 새 탭)
                  </a>
                </div>
              </details>
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  의료급여 대상이거나 보험 자격을 모르겠어요
                </summary>

                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  <div
                    style={{
                      paddingBottom: 20,
                      marginBottom: 20,
                      borderBottom: "1px solid #dedbd5",
                    }}
                  >
                    <h4
                      style={{
                        margin: "0 0 8px",
                        fontSize: 14,
                        fontWeight: 700,
                        color: "#1a1918",
                      }}
                    >
                      의료급여 대상이에요
                    </h4>

                    <p style={{ margin: "0 0 12px" }}>
                      <strong>보청기를 구입하기 전에</strong> 주소지
                      주민센터에서 신청·승인 순서를 확인하세요.
                    </p>

                    <div
                      style={{
                        padding: "12px 14px",
                        marginBottom: 8,
                        background: "#efeeea",
                        borderRadius: 6,
                      }}
                    >
                      <strong>이렇게 물어보세요</strong>
                      <p style={{ margin: "4px 0 0" }}>
                        “의료급여 대상자로 보청기 지원을 신청하려고 해요. 구입
                        전에 처방전 발급과 신청·승인을 어떤 순서로 진행해야
                        하나요?”
                      </p>
                    </div>

                    <a
                      href="https://www.bokjiro.go.kr/ssis-tbu/twatca/wlfcl/wlfclPage.do"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        minHeight: 44,
                        color: "#1e3a8a",
                        textDecoration: "underline",
                        textUnderlineOffset: 3,
                      }}
                    >
                      복지로에서 주민센터 찾기 ↗ (새 탭)
                    </a>

                    <p style={{ margin: "0", fontSize: 13 }}>
                      ‘주소검색’에서 거주 지역을 설정하고, ‘공공기관 →
                      주민센터’를 선택하세요. 찾은 곳이 주소지 담당 주민센터인지
                      확인하세요.
                    </p>
                  </div>

                  <div>
                    <h4
                      style={{
                        margin: "0 0 8px",
                        fontSize: 14,
                        fontWeight: 700,
                        color: "#1a1918",
                      }}
                    >
                      건강보험인지 의료급여인지 모르겠어요
                    </h4>

                    <p style={{ margin: "0 0 12px" }}>
                      먼저 현재 보험 자격을 확인하세요. 국민건강보험공단에 글로
                      문의할 수 있어요.
                    </p>

                    <div
                      style={{
                        padding: "12px 14px",
                        marginBottom: 8,
                        background: "#efeeea",
                        borderRadius: 6,
                      }}
                    >
                      <strong>이렇게 물어보세요</strong>
                      <p style={{ margin: "4px 0 0" }}>
                        “제가 현재 건강보험과 의료급여 중 어디에 해당하나요?
                        건강보험이라면 차상위 본인부담경감 대상자로 등록되어
                        있는지도 확인해 주세요.”
                      </p>
                    </div>

                    <a
                      href="https://www.nhis.or.kr/nhis/minwon/retrieveCvaplCstInfoColctAgreView.do"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        minHeight: 44,
                        color: "#1e3a8a",
                        textDecoration: "underline",
                        textUnderlineOffset: 3,
                      }}
                    >
                      공단에 글로 문의하기 ↗ (새 탭)
                    </a>

                    <p style={{ margin: "0", fontSize: 13 }}>
                      로그인이 필요해요. 공단 홈페이지의 ‘국민소통·참여 → 온라인
                      상담문의 → 개인 상담’에서도 찾을 수 있어요.
                    </p>
                  </div>

                  <div
                    style={{
                      marginTop: 20,
                      paddingTop: 16,
                      borderTop: "1px solid #dedbd5",
                    }}
                  >
                    <p style={{ margin: 0 }}>
                      제도나 문의처가 헷갈린다면 채팅으로 물어볼 수 있어요.
                    </p>

                    <a
                      href="https://129.go.kr/counsel/counsel03.do"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        minHeight: 44,
                        color: "#1e3a8a",
                        textDecoration: "underline",
                        textUnderlineOffset: 3,
                      }}
                    >
                      129 채팅상담 안내 보기 ↗ (새 탭)
                    </a>
                  </div>
                </div>
              </details>
            </section>

            {/* 3. 양쪽 지원 */}
            <section id="one-or-two" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                아동·청소년 양쪽 지원
              </h3>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 10,
                }}
              >
                이 건강보험 제도의 보청기 지원은 기본적으로 한쪽 기준이에요.{" "}
                <strong>19세 미만의 청각장애 등록자</strong>는 추가 검사 조건을
                모두 충족하면 양쪽 보청기 지원이 가능해요.
              </p>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 12,
                  fontWeight: 600,
                }}
              >
                즉, 나이만으로 양쪽 지원이 확정되지는 않아요.
              </p>
              <button
                type="button"
                onClick={() => goTo("bilateral")}
                style={{
                  minHeight: 44,
                  padding: "10px 18px",
                  fontSize: 13,
                  color: "#1A1918",
                  backgroundColor: "transparent",
                  border: "1.5px solid #D0CEC9",
                  borderRadius: 2,
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}
              >
                아동·청소년 양쪽 지원 안내 보기 →
              </button>
            </section>

            {/* 4. 지원 금액 */}
            <section id="benefit" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                지원 금액
              </h3>
              <p
                style={{
                  fontSize: 13,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginBottom: 14,
                }}
              >
                기준액은 건강보험 일반 대상과 차상위 본인부담경감 대상자가
                공통으로 사용하는 지원액 계산 한도예요. '적합관리'는 보청기를 잘
                사용할 수 있도록 조절·관리하는 서비스예요.
              </p>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                  marginBottom: 14,
                }}
              >
                <div
                  style={{
                    padding: "14px 16px",
                    border: "1px solid #D0CEC9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 4,
                      letterSpacing: "0.04em",
                    }}
                  >
                    처음 청구 · 기준액 111만 원 (제품 91만 원 + 초기 관리 20만
                    원)
                  </p>
                  <p
                    style={{
                      fontSize: 12,
                      color: "#6B6864",
                      lineHeight: 1.5,
                      marginBottom: 8,
                    }}
                  >
                    구입 후 1개월이 지난 뒤 병원 검수확인을 받고 청구해요. 두
                    비용은 함께 지급돼요.
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 8,
                      flexWrap: "wrap",
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      건강보험 일반 대상 · 90%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      최대 99만 9천 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 8,
                      flexWrap: "wrap",
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      차상위 본인부담경감 대상자 · 100%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      최대 111만 원
                    </strong>
                  </div>
                </div>
                <div
                  style={{
                    padding: "14px 16px",
                    border: "1px solid #D0CEC9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 4,
                      letterSpacing: "0.04em",
                    }}
                  >
                    이후 청구 · 연 5만 원 × 최대 4회 (기준액 합계 20만 원)
                  </p>
                  <p
                    style={{
                      fontSize: 12,
                      color: "#6B6864",
                      lineHeight: 1.5,
                      marginBottom: 8,
                    }}
                  >
                    구입 1년 후부터 5년까지의 관리 비용이에요. 매년 1회 이상
                    실제 관리를 받은 뒤, 연 1회씩 따로 청구해요.
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 8,
                      flexWrap: "wrap",
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      건강보험 일반 대상 · 90%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      연 최대 4만 5천 원 / 합계 18만 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 8,
                      flexWrap: "wrap",
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      차상위 본인부담경감 대상자 · 100%
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      연 최대 5만 원 / 합계 20만 원
                    </strong>
                  </div>
                </div>
                <div
                  style={{
                    padding: "14px 16px",
                    backgroundColor: "#F0EEE9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 4,
                      letterSpacing: "0.04em",
                    }}
                  >
                    전체 합계 · 기준액 131만 원
                  </p>
                  <p
                    style={{
                      fontSize: 12,
                      color: "#6B6864",
                      lineHeight: 1.5,
                      marginBottom: 8,
                    }}
                  >
                    처음 청구와 이후 관리 비용을 합한 금액이며, 한 번에 지급되는
                    돈은 아니에요.
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 8,
                      flexWrap: "wrap",
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      건강보험 일반 대상 · 90%
                    </span>
                    <strong style={{ fontSize: 15, color: "#1A1918" }}>
                      총 최대 117만 9천 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 8,
                      flexWrap: "wrap",
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      차상위 본인부담경감 대상자 · 100%
                    </span>
                    <strong style={{ fontSize: 15, color: "#1A1918" }}>
                      총 최대 131만 원
                    </strong>
                  </div>
                </div>
              </div>
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginBottom: 8,
                }}
              >
                실제 지원액은 제품별 고시금액과 구입금액 등에 따라 달라져요.
                100% 지원도 지원 대상으로 인정되는 금액 기준이에요.
              </p>
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  내 지급액이 안내된 최대 금액과 달라질 수 있나요?
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  <p style={{ marginBottom: 8 }}>
                    건강보험은 기본적으로 지급기준금액의 90%를 지원해요. 제품의
                    고시가격이나 실제 구입가격이 낮으면 지원액도 줄어들 수
                    있어요.
                  </p>
                  <p style={{ marginBottom: 8 }}>
                    차상위 본인부담경감 대상 등은 같은 건강보험 안에서 100%
                    지원이 적용돼요. 기준을 넘는 비용까지 모두 지원한다는 뜻은
                    아니에요. 본인의 경감 적용 여부는 국민건강보험공단에서
                    확인하세요. 의료급여는 별도 절차를 확인하세요.
                  </p>
                  <p>
                    제품별 고시가격에는 초기 관리비가 이미 포함되어 있어요.
                    고시가격에 20만 원을 다시 더하지 않아요.
                  </p>
                </div>
              </details>
            </section>

            {/* 5. 5단계 절차 */}
            <section id="steps" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                5단계 진행 절차
              </h3>
              <ExpandableJourneySteps
                steps={BASE.map((b, i) => ({
                  ...b,
                  institution: stepInstitution(i, null),
                  status: "future" as StepStatus,
                  statusLabel: "",
                  detailLines: stepDetails(i, null, null),
                }))}
              />
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  이미 구입했는데 등록·처방 절차를 거치지 않았어요
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  구입했다고 무조건 지원되거나 지원이 불가능하다고 단정할 수는
                  없어요. 처방일·구입일·장애등록일과 구입 자료를 가지고
                  국민건강보험공단에 적용 가능 여부를 먼저 확인하세요.
                </div>
              </details>
            </section>

            {/* 6. 구입 전 센터·제품 등록 확인 */}
            <section id="center-product-check" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                구입 전 센터·제품 등록 확인
              </h3>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 10,
                }}
              >
                구입할 센터와 추천받은 제품은 각각 등록 여부를 확인해야 해요.
                <br />
                센터명·주소와 정확한 제품 모델명을 준비하세요.
              </p>
              <button
                type="button"
                onClick={() => goTo("product")}
                style={{
                  minHeight: 44,
                  padding: "10px 18px",
                  fontSize: 13,
                  fontWeight: 600,
                  color: "#1A1918",
                  backgroundColor: "transparent",
                  border: "1.5px solid #1A1918",
                  borderRadius: 2,
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}
              >
                센터·제품 등록 확인하기 →
              </button>
            </section>

            {/* 7. 센터 상담 준비 */}
            <section id="before-buying" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                센터 상담 준비
              </h3>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 14,
                }}
              >
                센터 방문 전에 공통으로 물어볼 질문 3개예요.
              </p>
              <ol
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: 0,
                  display: "flex",
                  flexDirection: "column",
                  gap: 10,
                  marginBottom: 16,
                }}
              >
                {[
                  "공단 등록 판매업소인가요? 추천해 주신 정확한 모델명과 급여 등록 여부도 알려주세요.",
                  "제가 내는 총금액은 얼마인가요? 초기·후기 관리와 수리 비용은 어떻게 나뉘나요?",
                  "청구를 맡길 수 있나요? 제가 직접 병원에 가거나 받아올 서류는 무엇이고, 다음 방문은 언제인가요?",
                ].map((q, i) => (
                  <li
                    key={i}
                    style={{
                      padding: "12px 16px",
                      border: "1px solid #D0CEC9",
                      borderRadius: 2,
                      fontSize: 13,
                      color: "#1A1918",
                      lineHeight: 1.6,
                    }}
                  >
                    <span style={{ fontWeight: 700, marginRight: 6 }}>
                      {i + 1}.
                    </span>
                    {q}
                  </li>
                ))}
              </ol>
              <details
                style={{
                  marginTop: 12,
                  marginBottom: 12,
                  background: "#f3f6fb",
                  border: "1px solid #dce3ed",
                  borderRadius: 8,
                }}
              >
                <summary
                  style={{
                    padding: "12px 14px",
                    fontSize: 14,
                    fontWeight: 600,
                    lineHeight: 1.6,
                    color: "#1a1918",
                    cursor: "pointer",
                    userSelect: "none",
                  }}
                >
                  직접 청구하려면 서류를 어디서 받나요?
                </summary>
                <div
                  style={{
                    padding: "0 14px 16px 28px",
                    fontSize: 14,
                    color: "#4a4845",
                    lineHeight: 1.8,
                    overflowWrap: "anywhere",
                  }}
                >
                  병원: 지원금 신청용 보청기 처방전·검사 자료, 구입 후
                  검수확인서. 판매업소: 구매 계약서·영수증 등 구입 증빙과 제품
                  바코드 확인 자료. 공단: 지급청구서와 위 자료 제출, 추가
                  자료·접수 방법 사전 확인. 판매업소에 위임한다면 위임장·신분증
                  사본 등 본인이 제공할 자료를 안내받으세요.
                </div>
              </details>
            </section>

            {/* 7. 출처 */}
            <section id="sources" style={{ marginBottom: 36 }}>
              <h3
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  scrollMarginTop: 20,
                }}
              >
                공식 출처
              </h3>
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginBottom: 12,
                }}
              >
                아래는 이번 안내에 사용한 공식 자료예요. 링크는 새 탭으로
                열려요.
              </p>
              <ul
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: 0,
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                }}
              >
                {[
                  {
                    label: "장애인등록·장애정도 심사 안내 · 보건복지부",
                    href: "https://www.mohw.go.kr/menu.es?mid=a10710010900",
                    date: "2026-09-24 재확인",
                  },
                  {
                    label:
                      "장애인보조기기 보험급여 기준 등 세부사항 · 보건복지부·공단",
                    href: "https://www.nhis.or.kr/lm/lmxsrv/law/lawFullView.do?SEQ=87&SEQ_HISTORY=613408",
                    date: "제2026-56호 · 2026-09-24 재확인",
                  },
                  {
                    label: "국민건강보험법 시행규칙 제26조 · 국가법령정보센터",
                    href: "https://www.law.go.kr/LSW/lsSideInfoP.do?docCls=jo&joBrNo=00&joNo=0026&lsiSeq=288087&urlMode=lsScJoRltInfoR",
                    date: "2026-08-11 시행 · 2026-09-24 재확인",
                  },
                  {
                    label: "보청기 급여제품 및 결정가격 고시 · 보건복지부·공단",
                    href: "https://www.nhis.or.kr/lm/lmxsrv/law/lawFullContent.do?SEQ=1619&SEQ_HISTORY=613524",
                    date: "제2026-86호 · 제품 목록 2026-09-23 확인",
                  },
                  {
                    label: "장애인 보조기기 지원 안내 · 법제처 생활법령정보",
                    href: "https://easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=4&cnpClsNo=1&csmSeq=1063&popMenu=ov",
                    date: "",
                  },
                  {
                    label: "양쪽 지원: 국민건강보험법 시행규칙 별표 7",
                    href: "https://www.law.go.kr/flDownload.do?bylClsCd=110201&flSeq=162807869&gubun=",
                    date: "2026-09-25 확인 · PDF 새 탭",
                  },
                ].map(({ label, href, date }) => (
                  <li key={href} style={{ fontSize: 13, lineHeight: 1.5 }}>
                    <a
                      href={href}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ color: "#1E3A8A" }}
                    >
                      {label}
                    </a>
                    {date && (
                      <span
                        style={{
                          color: "#908D88",
                          fontSize: 12,
                          marginLeft: 8,
                        }}
                      >
                        {date}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </section>

            <div style={{ borderTop: "1px solid #E8E6E1", paddingTop: 20 }}>
              <button
                type="button"
                onClick={goBackFromInner}
                style={{
                  fontSize: 13,
                  color: "#1E3A8A",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontFamily: "inherit",
                  padding: "8px 0",
                  minHeight: 44,
                }}
              >
                {backLabel()}
              </button>
            </div>
          </div>
        )}

        {/* ── Bilateral (보호자·양쪽 지원) ── */}
        {view === "bilateral" && (
          <div style={inner}>
            <button
              type="button"
              onClick={goBackFromInner}
              style={{
                fontSize: 13,
                color: "#1E3A8A",
                background: "none",
                border: "none",
                cursor: "pointer",
                fontFamily: "inherit",
                padding: "0 0 20px",
                minHeight: 44,
              }}
            >
              {backLabel()}
            </button>
            <h2
              id="bilateral-heading"
              tabIndex={-1}
              style={{
                fontSize: 20,
                fontWeight: 700,
                color: "#1A1918",
                marginBottom: 8,
                letterSpacing: "-0.02em",
                outline: "none",
              }}
            >
              아이의 보청기, 양쪽 모두 지원받을 수 있나요?
            </h2>

            <div style={{ marginBottom: 24 }}>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 8,
                }}
              >
                이 건강보험 제도의 보청기 지원은 기본적으로 한쪽 기준이에요.{" "}
                <strong>19세 미만의 청각장애 등록자</strong>는 추가 검사 조건을
                모두 충족하면 양쪽 보청기 지원이 가능해요.
              </p>
              <p
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 8,
                }}
              >
                나이만으로 양쪽 지원이 확정되지는 않아요.
              </p>
              <p style={{ fontSize: 13, color: "#908D88", lineHeight: 1.6 }}>
                아래는 공통 안내예요. 개인별 지원 자격과 실제 금액은 확인이
                필요해요.
              </p>
            </div>

            {/* 지금 확인할 일 */}
            <div
              style={{
                padding: "16px 18px",
                backgroundColor: "#FFFBEB",
                borderRadius: 2,
                marginBottom: 24,
                borderTop: "1px solid #FDE68A",
                borderBottom: "1px solid #FDE68A",
                borderLeft: "1px solid #FDE68A",
                borderRight: "1px solid #FDE68A",
              }}
            >
              <p
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: "#78350F",
                  marginBottom: 6,
                }}
              >
                지금 확인할 일
              </p>
              <p
                style={{
                  fontSize: 14,
                  color: "#1A1918",
                  lineHeight: 1.6,
                  marginBottom: 8,
                }}
              >
                이비인후과에서 아이가 양쪽 지원 조건에 해당하는지 물어보세요.
                검사 수치를 직접 해석하지 않아도 괜찮아요.
              </p>
              <button
                type="button"
                onClick={() => {
                  const el = bilateralQsRef.current
                  if (!el) return
                  el.scrollIntoView({
                    behavior: prefersReduced ? "auto" : "smooth",
                    block: "start",
                  })
                  setTimeout(
                    () => el.focus({ preventScroll: true }),
                    prefersReduced ? 0 : 300,
                  )
                }}
                style={{
                  fontSize: 13,
                  color: "#1E3A8A",
                  textDecoration: "underline",
                  fontWeight: 600,
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontFamily: "inherit",
                  padding: 0,
                  minHeight: 44,
                  display: "inline-block",
                }}
              >
                병원·센터 질문 보기 ↓
              </button>
            </div>

            {/* 검사 조건 */}
            <details
              style={{
                marginTop: 12,
                marginBottom: 12,
                background: "#f3f6fb",
                border: "1px solid #dce3ed",
                borderRadius: 8,
              }}
            >
              <summary
                style={{
                  padding: "12px 14px",
                  fontSize: 14,
                  fontWeight: 600,
                  lineHeight: 1.6,
                  color: "#1a1918",
                  cursor: "pointer",
                  userSelect: "none",
                }}
              >
                병원에서는 어떤 검사 조건을 확인하나요?
              </summary>
              <div
                style={{
                  padding: "0 14px 16px 28px",
                  fontSize: 14,
                  color: "#4a4845",
                  lineHeight: 1.8,
                  overflowWrap: "anywhere",
                }}
              >
                <p style={{ marginBottom: 8 }}>
                  청력장애로 등록된 청각장애인 중 건강보험 가입자·피부양자이며
                  이비인후과 전문의가 일상생활에 도움이 된다고 판단하는 기본
                  요건에 더해 다음 모두가 필요해요.
                </p>
                <ul
                  style={{
                    margin: 0,
                    padding: 0,
                    listStyle: "none",
                    display: "flex",
                    flexDirection: "column",
                    gap: 6,
                  }}
                >
                  {[
                    "19세 미만",
                    "양쪽 모두 80dB 미만의 난청 — dB(데시벨)는 청력검사에서 사용하는 소리 크기 단위",
                    "양쪽 말소리명료도 각각 50% 이상 — 들은 말소리를 얼마나 정확히 구별하는지 보는 검사",
                    "양쪽 순음청력역치 차이 15dB 이하 — 검사 소리를 겨우 들을 수 있는 크기의 두 귀 차이",
                    "양쪽 말소리명료도 차이 20% 이하",
                  ].map((item, i) => (
                    <li
                      key={i}
                      style={{
                        paddingLeft: 12,
                        borderLeft: "2px solid #D0CEC9",
                        fontSize: 13,
                        lineHeight: 1.6,
                      }}
                    >
                      {item}
                    </li>
                  ))}
                </ul>
                <p style={{ marginTop: 10, fontSize: 12, color: "#908D88" }}>
                  의식이 명료하지 않거나 보청기를 사용할 수 없다고 전문의가
                  판단하면 한쪽·양쪽 모두 적용에서 제외될 수 있어요. (출처: 고시
                  별표 2 제4호)
                </p>
              </div>
            </details>

            {/* 금액 예시 */}
            <div style={{ marginBottom: 24 }}>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.6,
                  marginBottom: 6,
                  fontWeight: 600,
                }}
              >
                양쪽 지원 대상자로 인정된 경우의 예시예요.
              </p>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.6,
                  marginBottom: 8,
                }}
              >
                두 보청기 각각에 최대 지급 기준이 적용되고 후기 관리 조건까지
                충족했을 때의 합계예요.
              </p>
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginBottom: 6,
                }}
              >
                공식 기준에 따라 계산한 양쪽 최대 금액 예시예요. 실제 지원액은
                각 제품의 고시금액·구입금액과 관리 조건에 따라 달라져요.
              </p>
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginBottom: 14,
                }}
              >
                100%도 지원 대상으로 인정되는 금액 기준이에요. 아동이라는
                이유만으로 100% 지원 자격이 되지 않아요.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <div
                  style={{
                    padding: "14px 16px",
                    border: "1px solid #D0CEC9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 6,
                    }}
                  >
                    건강보험 일반 대상 · 90%
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: 4,
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      처음 최대 (한쪽 99만 9천 원 × 2)
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      199만 8천 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: 4,
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      후기 연 최대 (한쪽 4만 5천 원 × 2)
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      연 9만 원 / 4회 합계 36만 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: 4,
                      borderTop: "1px solid #D0CEC9",
                      paddingTop: 6,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      전체 총 최대
                    </span>
                    <strong style={{ fontSize: 15, color: "#1A1918" }}>
                      235만 8천 원
                    </strong>
                  </div>
                </div>
                <div
                  style={{
                    padding: "14px 16px",
                    backgroundColor: "#F0EEE9",
                    borderRadius: 2,
                  }}
                >
                  <p
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: "#908D88",
                      marginBottom: 6,
                    }}
                  >
                    차상위 본인부담경감 대상자 · 100%
                  </p>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: 4,
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      처음 최대 (한쪽 111만 원 × 2)
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      222만 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: 4,
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      후기 연 최대 (한쪽 5만 원 × 2)
                    </span>
                    <strong style={{ fontSize: 14, color: "#1A1918" }}>
                      연 10만 원 / 4회 합계 40만 원
                    </strong>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: 4,
                      borderTop: "1px solid #D0CEC9",
                      paddingTop: 6,
                    }}
                  >
                    <span style={{ fontSize: 13, color: "#4A4845" }}>
                      전체 총 최대
                    </span>
                    <strong style={{ fontSize: 15, color: "#1A1918" }}>
                      262만 원
                    </strong>
                  </div>
                </div>
              </div>
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginTop: 10,
                }}
              >
                전체 합계는 한 번에 지급되지 않아요. 처음은 구입 후 1개월 경과
                및 병원 검수 후 청구, 후기는 구입 1년 후부터 5년까지 매년 실제
                관리 후 따로 청구해요.
              </p>
            </div>

            <details
              style={{
                marginTop: 12,
                marginBottom: 12,
                background: "#f3f6fb",
                border: "1px solid #dce3ed",
                borderRadius: 8,
              }}
            >
              <summary
                style={{
                  padding: "12px 14px",
                  fontSize: 14,
                  fontWeight: 600,
                  lineHeight: 1.6,
                  color: "#1a1918",
                  cursor: "pointer",
                  userSelect: "none",
                }}
              >
                공식 근거와 양쪽 금액 계산 방법 보기
              </summary>
              <div
                style={{
                  padding: "0 14px 16px 28px",
                  fontSize: 14,
                  color: "#4a4845",
                  lineHeight: 1.8,
                  overflowWrap: "anywhere",
                }}
              >
                <p style={{ marginBottom: 6 }}>
                  아래는 공식 기준을 적용해 IYUM에서 계산한 합산 상한이에요.
                  고시에 이 양쪽 합계 금액이 직접 적혀 있다는 뜻은 아니에요.
                </p>
                <p style={{ marginBottom: 6 }}>
                  직접 명시된 기준: 시행규칙 별표 7 제1호 라목·라목 1)의
                  내구연한 내 1인당 한 번 일반원칙과 양쪽 장착 각각 1회 예외;
                  제3호의 기준액·고시금액·실구입금액 중 가장 낮은 지급기준금액과
                  90%/100%; 고시 별표 2 제4호의 양쪽 조건; 별표 5 아목 10)의
                  한쪽 기준액 131만 원(적합관리 40만 원 포함)·내구연한 5년;
                  제5조의2/별표 4의 초기 20만 원, 후기 연 5만 원·최대 4회.
                </p>
                <p style={{ marginBottom: 6 }}>
                  한쪽 제품 91만 원 = 131만 원 − 관리 40만 원. 처음 111만 원 =
                  제품 91만 원 + 초기 20만 원.
                </p>
                <p style={{ marginBottom: 6 }}>
                  일반: 처음 111만 원 × 90% × 2 = 199만 8천 원. 후기: 5만 원 ×
                  90% × 2 × 4 = 36만 원. 전체 235만 8천 원.
                </p>
                <p style={{ marginBottom: 10 }}>
                  경감: 처음 111만 원 × 100% × 2 = 222만 원. 후기: 5만 원 × 100%
                  × 2 × 4 = 40만 원. 전체 262만 원.
                </p>
                <p style={{ fontSize: 12, color: "#908D88", marginBottom: 6 }}>
                  후기 관리는 급여를 받은 기기를 지속적으로 사용하고 실제
                  관리받는 조건이에요. 각 기기의 최대 지급·관리 조건을
                  충족한다는 전제이며 개인별 지급 여부와 실제 금액은 공단 확인이
                  필요해요.
                </p>
                <p style={{ fontSize: 12, color: "#908D88", marginBottom: 6 }}>
                  확인일 2026-09-25. 원문 자료 (새 탭):
                </p>
                <ul
                  style={{
                    margin: 0,
                    padding: 0,
                    listStyle: "none",
                    display: "flex",
                    flexDirection: "column",
                    gap: 4,
                  }}
                >
                  <li>
                    <a
                      href="https://www.law.go.kr/flDownload.do?bylClsCd=110201&flSeq=162807869&gubun="
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ fontSize: 12, color: "#1E3A8A" }}
                    >
                      국민건강보험법 시행규칙 별표 7 (PDF)
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.nhis.or.kr/lm/lmxsrv/law/lawFullView.do?SEQ=87&SEQ_HISTORY=613408"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ fontSize: 12, color: "#1E3A8A" }}
                    >
                      장애인보조기기 보험급여 기준 등 세부사항 (공단)
                    </a>
                  </li>
                </ul>
              </div>
            </details>

            {/* 질문 */}
            <div id="bilateral-questions" style={{ scrollMarginTop: 20 }}>
              <h3
                ref={bilateralQsRef}
                id="bilateral-questions-heading"
                tabIndex={-1}
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 10,
                  outline: "none",
                  scrollMarginTop: 20,
                }}
              >
                병원과 센터에서 이렇게 물어보세요
              </h3>
              <ol
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: 0,
                  display: "flex",
                  flexDirection: "column",
                  gap: 10,
                  marginBottom: 0,
                }}
              >
                {[
                  {
                    institution:
                      "병원·이비인후과에서 / 양쪽 보청기 지원 가능 여부 문의",
                    q: "아이의 검사 결과가 건강보험 양쪽 보청기 지원 조건을 모두 충족하나요? 양쪽 지원을 위한 처방이 가능한가요?",
                  },
                  {
                    institution: "보청기센터에서 / 양쪽 보청기 비용 문의",
                    q: "양쪽을 구입하면 각 보청기의 지원액과 제가 부담할 총금액은 얼마인가요?",
                  },
                  {
                    institution: "보청기센터에서 / 사후 관리 문의",
                    q: "양쪽 보청기의 초기·후기 관리에 포함되는 서비스와 별도 비용, 다음 방문 일정은 어떻게 되나요?",
                  },
                ].map((item, i) => (
                  <li
                    key={i}
                    style={{
                      padding: "14px 16px",
                      border: "1px solid #D0CEC9",
                      borderRadius: 2,
                    }}
                  >
                    <p
                      style={{
                        fontSize: 11,
                        fontWeight: 600,
                        color: "#908D88",
                        marginBottom: 4,
                      }}
                    >
                      {item.institution}
                    </p>
                    <p
                      style={{
                        fontSize: 14,
                        color: "#1A1918",
                        lineHeight: 1.6,
                      }}
                    >
                      <span style={{ fontWeight: 700, marginRight: 6 }}>
                        {i + 1}.
                      </span>
                      {item.q}
                    </p>
                  </li>
                ))}
              </ol>
              <BilateralCopyButton
                successMsg="보호자 질문을 기관명과 함께 복사했어요. 휴대폰 메모 등에 붙여 넣어 보관하세요."
                copyText={[
                  "IYUM · 보호자의 양쪽 보청기 지원 상담 질문",
                  "건강보험 공통 안내를 바탕으로 준비한 질문이며, 아이의 지원 자격이나 금액을 확정한 결과가 아니에요.",
                  "",
                  "1. 병원 · 이비인후과",
                  "아이의 검사 결과가 건강보험 양쪽 보청기 지원 조건을 모두 충족하나요? 양쪽 지원을 위한 처방이 가능한가요?",
                  "",
                  "2. 보청기센터 · 비용",
                  "양쪽을 구입하면 각 보청기의 지원액과 제가 부담할 총금액은 얼마인가요?",
                  "",
                  "3. 보청기센터 · 관리",
                  "양쪽 보청기의 초기·후기 관리에 포함되는 서비스와 별도 비용, 다음 방문 일정은 어떻게 되나요?",
                ].join("\n")}
              />
            </div>

            {/* 별도 사업 안내 */}
            <div
              style={{
                marginTop: 32,
                borderTop: "1px solid #E8E6E1",
                paddingTop: 20,
              }}
            >
              <p
                style={{
                  fontSize: 13,
                  fontWeight: 600,
                  color: "#4A4845",
                  marginBottom: 6,
                }}
              >
                장애등록 기준에 해당하지 않는 아이는요?
              </p>
              <p
                style={{
                  fontSize: 13,
                  color: "#908D88",
                  lineHeight: 1.6,
                  marginBottom: 8,
                }}
              >
                아래는 건강보험 보청기 급여와는 다른 사업이에요.
              </p>
              <a
                href="https://www.bokjiro.go.kr/ssis-tbu/twataa/wlfareInfo/moveTWAT52011M.do?wlfareInfoId=WLF00001130"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  fontSize: 13,
                  color: "#1E3A8A",
                  textDecoration: "underline",
                }}
              >
                복지로 · 선천성 난청검사 및 보청기 지원 (새 탭)
              </a>
            </div>

            <div
              style={{
                borderTop: "1px solid #E8E6E1",
                paddingTop: 20,
                marginTop: 24,
              }}
            >
              <button
                type="button"
                onClick={goBackFromInner}
                style={{
                  fontSize: 13,
                  color: "#1E3A8A",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontFamily: "inherit",
                  padding: "8px 0",
                  minHeight: 44,
                }}
              >
                {backLabel()}
              </button>
            </div>
          </div>
        )}

        {/* ── Product (제품 확인) ── */}
        {view === "product" && (
          <div style={inner}>
            <button
              type="button"
              onClick={goBackFromInner}
              style={{
                fontSize: 13,
                color: "#1E3A8A",
                background: "none",
                border: "none",
                cursor: "pointer",
                fontFamily: "inherit",
                padding: "0 0 20px",
                minHeight: 44,
              }}
            >
              {backLabel()}
            </button>
            <h2
              id="registry-check"
              style={{
                fontSize: 20,
                fontWeight: 700,
                color: "#1A1918",
                marginBottom: 8,
                letterSpacing: "-0.02em",
              }}
            >
              센터·제품 등록 확인
            </h2>

            {/* 센터 확인 */}
            <div
              style={{
                marginBottom: 28,
                paddingBottom: 28,
                borderBottom: "1px solid #D0CEC9",
              }}
            >
              <h3
                style={{
                  fontSize: 15,
                  fontWeight: 700,
                  color: "#1A1918",
                  marginBottom: 8,
                }}
              >
                구입할 센터 확인
              </h3>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 6,
                }}
              >
                정확한 센터명과 주소를 준비해 공단에 문의하세요.
              </p>
              <p
                style={{
                  fontSize: 13,
                  color: "#4A4845",
                  lineHeight: 1.7,
                  marginBottom: 12,
                  padding: "10px 14px",
                  backgroundColor: "#F0EEE9",
                  borderRadius: 2,
                  fontStyle: "italic",
                }}
              >
                예: "○○센터, 주소 ○○가 보청기 건강보험 급여 등록 판매업소인지
                확인해 주세요."
              </p>
              <a
                href="https://www.nhis.or.kr/nhis/minwon/retrieveCvaplCstInfoColctAgreView.do"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  minHeight: 44,
                  padding: "10px 18px",
                  fontSize: 13,
                  fontWeight: 600,
                  color: "#1E3A8A",
                  textDecoration: "underline",
                  border: "1px solid #D0CEC9",
                  borderRadius: 2,
                }}
              >
                공단에 등록 여부 문의하기 (로그인 · 새 탭)
              </a>
              <p
                style={{
                  fontSize: 12,
                  color: "#908D88",
                  lineHeight: 1.5,
                  marginTop: 6,
                }}
              >
                즉시 조회되는 기능이 아니에요. 온라인 개인 상담으로 문의할 수
                있어요.
              </p>
            </div>

            <h3
              style={{
                fontSize: 15,
                fontWeight: 700,
                color: "#1A1918",
                marginBottom: 6,
              }}
            >
              추천받은 제품 확인
            </h3>
            <p style={{ fontSize: 12, color: "#908D88", lineHeight: 1.5, marginBottom: 10 }}>
              <a
                href={PRODUCTS_META.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "#1E3A8A", textDecoration: "underline" }}
              >
                공식 제품 목록에서 확인하기 ↗ (새 탭)
              </a>
              {" · 확인일: "}{PRODUCTS_META.checkedAt}
            </p>
            <p
              style={{
                fontSize: 13,
                color: "#908D88",
                lineHeight: 1.6,
                marginBottom: 14,
              }}
            >
              보청기 건강보험 급여 고시 제품 목록(
              {PRODUCTS_META.products.length}개)에서 모델명이나 제품코드를
              검색해요.
            </p>
            <div
              style={{
                padding: "10px 14px",
                backgroundColor: "#F0EEE9",
                borderRadius: 2,
                marginBottom: 20,
                fontSize: 12,
                color: "#4A4845",
                lineHeight: 1.6,
              }}
            >
              제품 등록 확인은 개인의 급여 자격 확인과 달라요. 판매업소 등록도
              별도로 확인해야 해요.
              <br />
              고시: {PRODUCTS_META.notice} · 시행 {PRODUCTS_META.effectiveAt} ·
              목록 확인 {PRODUCTS_META.checkedAt}
              {isDataStale && (
                <span
                  style={{ marginLeft: 6, color: "#92400E", fontWeight: 600 }}
                >
                  · 확인일 기준 7일 경과 — 최신 고시를 별도 확인하세요
                </span>
              )}
            </div>

            <div
              style={{
                display: "flex",
                gap: 8,
                marginBottom: 6,
                flexWrap: "wrap",
              }}
            >
              <input
                type="text"
                value={productQuery}
                onChange={(e) => {
                  setProductQuery(e.target.value)
                  setSelectedProduct(null)
                  setProductSearched(false)
                  setProductResults([])
                  setProductPage(0)
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleProductSearch()
                }}
                placeholder="모델명 · 제품코드 · 업체명"
                aria-label="제품 검색"
                style={{
                  flex: 1,
                  minWidth: 200,
                  minHeight: 44,
                  padding: "10px 14px",
                  fontSize: 14,
                  border: "1.5px solid #1A1918",
                  borderRadius: 2,
                  fontFamily: "inherit",
                  backgroundColor: "#FAFAF8",
                  boxSizing: "border-box",
                }}
              />
              <button
                type="button"
                onClick={handleProductSearch}
                style={{
                  minHeight: 44,
                  padding: "10px 20px",
                  fontSize: 14,
                  fontWeight: 600,
                  color: "#FAFAF8",
                  backgroundColor: "#1A1918",
                  border: "none",
                  borderRadius: 2,
                  cursor: "pointer",
                  fontFamily: "inherit",
                  whiteSpace: "nowrap",
                }}
              >
                검색
              </button>
            </div>

            {productSearched && !productResults.length && (
              <div
                style={{
                  padding: "14px 16px",
                  border: "1px solid #E8E6E1",
                  borderRadius: 2,
                  marginTop: 12,
                }}
              >
                <p
                  style={{
                    fontSize: 13,
                    color: "#4A4845",
                    lineHeight: 1.6,
                    marginBottom: 4,
                  }}
                >
                  이 목록에서 일치하는 제품을 찾지 못했어요.
                </p>
                <p style={{ fontSize: 12, color: "#908D88", lineHeight: 1.5 }}>
                  모델명과 제품코드를 다시 확인해 주세요. 검색 결과가 없다는
                  것만으로 미등록 제품이라고 판단할 수는 없어요.
                </p>
              </div>
            )}

            {productResults.length > 0 && (
              <div style={{ marginTop: 12 }}>
                <p style={{ fontSize: 12, color: "#908D88", marginBottom: 8 }}>
                  {productResults.length}개 결과 · 정확한 모델을 선택하세요
                </p>
                <ul
                  style={{
                    listStyle: "none",
                    padding: 0,
                    margin: 0,
                    display: "flex",
                    flexDirection: "column",
                    gap: 6,
                  }}
                >
                  {productResults.slice(0, (productPage + 1) * 6).map((p) => (
                    <li key={p.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedProduct(p)}
                        aria-pressed={selectedProduct?.id === p.id}
                        style={{
                          display: "block",
                          width: "100%",
                          minHeight: 44,
                          padding: "10px 14px",
                          textAlign: "left",
                          fontSize: 13,
                          color:
                            selectedProduct?.id === p.id
                              ? "#FAFAF8"
                              : "#1A1918",
                          backgroundColor:
                            selectedProduct?.id === p.id
                              ? "#1A1918"
                              : "#FAFAF8",
                          borderTop: "1px solid #D0CEC9",
                          borderBottom: "1px solid #D0CEC9",
                          borderLeft: "1px solid #D0CEC9",
                          borderRight: "1px solid #D0CEC9",
                          borderRadius: 2,
                          cursor: "pointer",
                          fontFamily: "inherit",
                          lineHeight: 1.4,
                        }}
                      >
                        <span style={{ fontWeight: 600 }}>{p.model}</span>
                        <span
                          style={{ marginLeft: 8, fontSize: 12, opacity: 0.7 }}
                        >
                          {p.company}
                        </span>
                        <span
                          style={{
                            marginLeft: 8,
                            fontSize: 11,
                            fontFamily: "'DM Mono', monospace",
                            opacity: 0.6,
                          }}
                        >
                          {p.id}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
                {(productPage + 1) * 6 < productResults.length && (
                  <button
                    type="button"
                    onClick={() => setProductPage((p) => p + 1)}
                    style={{
                      marginTop: 10,
                      fontSize: 13,
                      color: "#1E3A8A",
                      background: "none",
                      border: "none",
                      cursor: "pointer",
                      fontFamily: "inherit",
                      padding: "8px 0",
                      minHeight: 44,
                      textDecoration: "underline",
                    }}
                  >
                    더 보기 ({productResults.length - (productPage + 1) * 6}개
                    남음)
                  </button>
                )}
              </div>
            )}

            {selectedProduct && (
              <div
                style={{
                  marginTop: 20,
                  padding: "16px 18px",
                  border: "1.5px solid #1A1918",
                  borderRadius: 2,
                }}
              >
                <p
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: "#908D88",
                    marginBottom: 8,
                    letterSpacing: "0.04em",
                  }}
                >
                  선택한 제품
                </p>
                <p
                  style={{
                    fontSize: 15,
                    fontWeight: 700,
                    color: "#1A1918",
                    marginBottom: 4,
                  }}
                >
                  {selectedProduct.model}
                </p>
                <p style={{ fontSize: 13, color: "#4A4845", marginBottom: 2 }}>
                  {selectedProduct.company}
                </p>
                <p
                  style={{
                    fontSize: 12,
                    fontFamily: "'DM Mono', monospace",
                    color: "#908D88",
                    marginBottom: 12,
                  }}
                >
                  코드: {selectedProduct.id} · 그룹: {selectedProduct.group}
                </p>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "baseline",
                    gap: 8,
                    flexWrap: "wrap",
                    padding: "10px 14px",
                    backgroundColor: "#F0EEE9",
                    borderRadius: 2,
                    marginBottom: 10,
                  }}
                >
                  <span style={{ fontSize: 13, color: "#4A4845" }}>
                    고시가격
                  </span>
                  <strong style={{ fontSize: 16, color: "#1A1918" }}>
                    {formatPrice(selectedProduct.price)}
                  </strong>
                </div>
                <p
                  style={{
                    fontSize: 12,
                    color: "#908D88",
                    lineHeight: 1.5,
                    marginBottom: 4,
                  }}
                >
                  내가 받는 지원금이나 실제 판매가격과는 다를 수 있어요.
                </p>
                <p style={{ fontSize: 12, color: "#908D88", lineHeight: 1.5 }}>
                  출처: {PRODUCTS_META.notice} · 시행{" "}
                  {PRODUCTS_META.effectiveAt} · 목록 확인 {CHECKED_AT}
                </p>
                {isDataStale && (
                  <p style={{ fontSize: 12, color: "#92400E", marginTop: 6 }}>
                    확인일 기준 7일이 지났어요. 구입 전 최신 등록·가격을 다시
                    확인하세요.
                  </p>
                )}
                {resultCode === "R08" && r08ModelQuestion && (
                  <div
                    style={{
                      marginTop: 14,
                      paddingTop: 14,
                      borderTop: "1px solid #D0CEC9",
                    }}
                  >
                    <p
                      style={{
                        fontSize: 12,
                        fontWeight: 600,
                        color: "#78350F",
                        marginBottom: 6,
                      }}
                    >
                      내 상담 질문에 반영돼요 (건강보험 + 처음 신청 결과)
                    </p>
                    <p
                      style={{
                        fontSize: 13,
                        color: "#1A1918",
                        lineHeight: 1.6,
                        fontStyle: "italic",
                      }}
                    >
                      "{r08ModelQuestion}"
                    </p>
                  </div>
                )}
              </div>
            )}

            <div
              style={{
                borderTop: "1px solid #E8E6E1",
                paddingTop: 20,
                marginTop: 24,
              }}
            >
              <button
                type="button"
                onClick={goBackFromInner}
                style={{
                  fontSize: 13,
                  color: "#1E3A8A",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontFamily: "inherit",
                  padding: "8px 0",
                  minHeight: 44,
                }}
              >
                {backLabel()}
              </button>
            </div>
          </div>
        )}

        {/* ── Guided ── */}
        {view === "guided" && (
          <div style={inner}>
            <button
              type="button"
              onClick={() => setView("summary")}
              style={{
                fontSize: 13,
                color: "#1E3A8A",
                background: "none",
                border: "none",
                cursor: "pointer",
                fontFamily: "inherit",
                padding: "0 0 16px",
                minHeight: 44,
              }}
            >
              ← 30초 요약으로 돌아가기
            </button>

            <h2
              ref={guidedHeadingRef}
              tabIndex={-1}
              style={{
                fontSize: 20,
                fontWeight: 700,
                color: "#1A1918",
                letterSpacing: "-0.02em",
                marginBottom: 8,
                outline: "none",
              }}
            >
              내 상황 확인하기
            </h2>

            {/* Instructions */}
            <div
              style={{
                marginBottom: 16,
                padding: "12px 14px",
                backgroundColor: "#F0EEE9",
                borderRadius: 2,
              }}
            >
              <p
                style={{
                  fontSize: 12,
                  color: "#4A4845",
                  lineHeight: 1.6,
                  marginBottom: 4,
                }}
              >
                아는 내용만 선택해 주세요. 필요한 질문만 확인하고, 센터에서
                물어볼 질문을 정리해 드릴게요.
              </p>
              <p
                style={{
                  fontSize: 12,
                  color: "#4A4845",
                  lineHeight: 1.6,
                  marginBottom: 4,
                }}
              >
                보호자가 대신 확인한다면, 보청기를 사용할 분의 등록 상태와 보험
                자격을 기준으로 답해 주세요.
              </p>
              <p style={{ fontSize: 12, color: "#908D88", lineHeight: 1.5 }}>
                답변은 서버에 저장·전송되지 않으며 새로고침하면 사라져요.
              </p>
            </div>

            {/* Compact journey bar */}
            <CompactJourneyBar steps={topBarSteps} />

            {/* Q1 */}
            {q1IsCollapsed && (
              <PreviousAnswer
                num={1}
                questionText="청각장애 진단·등록은 어디까지 진행하셨나요?"
                selectedLabel={q1Label}
                onEdit={() => {
                  setQ1(null)
                  setQ2(null)
                  setQ3(null)
                  setQ4(null)
                }}
              />
            )}
            {q1IsOpen && (
              <QuestionBlock
                num={1}
                question="청각장애 진단·등록은 어디까지 진행하셨나요?"
                desc="병원 검사·진단 뒤에는 주민센터에 자료를 내고 심사를 거쳐야 등록돼요."
                subtext="주민센터에서 청각장애 등록 완료 안내를 받았는지 떠올려 보세요. 다른 장애로 등록된 것과는 구분해요."
                options={Q1_OPTS}
                selected={q1}
                onSelect={handleQ1}
              />
            )}

            {/* Q2 */}
            {q2IsCollapsed && (
              <PreviousAnswer
                num={2}
                questionText="건강보험과 의료급여 중 어디에 해당하나요?"
                selectedLabel={q2Label}
                onEdit={() => {
                  setQ2(null)
                  setQ3(null)
                  setQ4(null)
                }}
              />
            )}
            {q2IsOpen && (
              <QuestionBlock
                num={2}
                question="건강보험과 의료급여 중 어디에 해당하나요?"
                desc="직장·지역 건강보험이나 가족의 건강보험에 포함되어 있다면 건강보험이에요. 의료급여는 생활이 어려운 분 등의 의료비를 지원하는 별도 제도예요."
                subtext="모르면 처방전 등 아는 내용부터 이어서 확인해요. 보험 자격은 미확인으로 남겨둘게요."
                options={Q2_OPTS}
                selected={q2}
                onSelect={handleQ2}
              />
            )}

            {/* Q3 */}
            {q3IsCollapsed && (
              <PreviousAnswer
                num={3}
                questionText="이비인후과에서 지원금 신청용 보청기 처방전을 받았나요?"
                selectedLabel={q3Label}
                onEdit={() => {
                  setQ3(null)
                  setQ4(null)
                  setQ5(null)
                }}
              />
            )}
            {q3IsOpen && (
              <QuestionBlock
                num={3}
                question="이비인후과에서 지원금 신청용 보청기 처방전을 받았나요?"
                desc="장애등록을 위한 진단서나 보청기를 권유받은 것과 달라요. 지원금 신청에 쓰는 공식 서류는 '보조기기 처방전'이에요."
                subtext="서류 이름이 기억나지 않으면 '잘 모르겠어요'를 선택하세요."
                options={Q3_OPTS}
                selected={q3}
                onSelect={handleQ3}
              />
            )}

            {/* Q4 */}
            {q4IsCollapsed && (
              <PreviousAnswer
                num={4}
                questionText="이전에 보청기 지원금을 받은 적이 있나요?"
                selectedLabel={q4Label}
                onEdit={() => setQ4(null)}
              />
            )}
            {q4IsOpen && (
              <QuestionBlock
                num={4}
                question="이전에 보청기 지원금을 받은 적이 있나요?"
                desc="처음 신청하는지, 이전 지원 이력을 확인해야 하는지 알아보기 위한 질문이에요."
                options={Q4_OPTS}
                selected={q4}
                onSelect={handleQ4}
              />
            )}

            {/* Q5 */}
            {q5IsCollapsed && (
              <PreviousAnswer
                num={4}
                questionText="주민센터에서 이번 보청기 지원 신청 결과를 안내받았나요?"
                selectedLabel={q5Label}
                onEdit={() => setQ5(null)}
              />
            )}
            {q5IsOpen && (
              <QuestionBlock
                num={4}
                question="주민센터에서 이번 보청기 지원 신청 결과를 안내받았나요?"
                desc="의료급여 수급자 선정 안내가 아니라, 이번 보청기 지원 신청에 대한 결과를 말해요."
                options={Q5_OPTS}
                selected={q5}
                onSelect={handleQ5}
              />
            )}

            {/* Result */}
            {currentStep === "done" && resultCode && (
              <ResultSection
                code={resultCode}
                info={RESULT_INFO[resultCode]}
                facts={computeFacts(q1, q2, q3, q4, resultCode, q5)}
                journey={computeJourney(q1, q2, q3, q4, q5)}
                headingRef={resultHeadingRef}
                onReset={handleReset}
                onGoTo={goTo}
                overrideQ1={resultCode === "R08" ? r08ModelQuestion : null}
              />
            )}
          </div>
        )}
      </div>
    </main>
  )
}
